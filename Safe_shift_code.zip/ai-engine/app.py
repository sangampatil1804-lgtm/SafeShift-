"""
app.py — Main entry point for the Edge AI Fatigue & Microsleep Detection System.

Orchestrates the full pipeline:
  Camera → Landmarks → EAR → Sensor Fusion → KNN Prediction → Alert → Log

Optimized for Raspberry Pi 4 with Python 3.11.
"""

import cv2
import time
import logging
import threading
import pickle
import os

from detector.landmarks import FaceLandmarkDetector
from detector.ear import calculate_ear
from sensor.esp_receiver import start_sensor_server, get_latest_sensor_data
from fusion.combine import combine_features
from alerts.buzzer import trigger_alert, clear_alert
from logs.logger import setup_logger, log_event

# ── Configuration ─────────────────────────────────────────────────────────────

CAMERA_INDEX       = 0          # Default Pi camera / USB webcam
FRAME_WIDTH        = 640
FRAME_HEIGHT       = 480
TARGET_FPS         = 15         # Lower FPS to reduce CPU load on RPi4
MODEL_PATH         = "knn_model.pkl"
EAR_CONSEC_FRAMES  = 3          # Frames below threshold before alert
LOG_LEVEL          = logging.INFO

# KNN prediction label mapping
LABELS = {0: "Normal", 1: "Fatigue", 2: "Drowsy", 3: "Microsleep"}

# ── Logger setup ──────────────────────────────────────────────────────────────

logger = setup_logger("app", level=LOG_LEVEL)


# ── Model loader ──────────────────────────────────────────────────────────────

def load_model(path: str):
    """Load pre-trained KNN model from disk. Returns None if not found."""
    if not os.path.exists(path):
        logger.warning(f"Model file '{path}' not found. Running in demo mode.")
        return None
    try:
        with open(path, "rb") as f:
            model = pickle.load(f)
        logger.info(f"KNN model loaded from '{path}'.")
        return model
    except Exception as e:
        logger.error(f"Failed to load model: {e}")
        return None


# ── Prediction ────────────────────────────────────────────────────────────────

def predict_state(model, features: list) -> str:
    """
    Run KNN prediction on the combined feature vector.
    Falls back to rule-based EAR threshold if model is unavailable.
    """
    if model is not None:
        try:
            prediction = model.predict([features])[0]
            return LABELS.get(int(prediction), "Unknown")
        except Exception as e:
            logger.error(f"Prediction error: {e}")

    # Fallback: rule-based using EAR (index 0 in features)
    ear = features[0] if features else 0.3
    if ear < 0.15:
        return "Microsleep"
    elif ear < 0.20:
        return "Drowsy"
    elif ear < 0.25:
        return "Fatigue"
    return "Normal"


# ── Main pipeline ─────────────────────────────────────────────────────────────

def main():
    logger.info("Starting Fatigue Detection System...")

    # Load KNN model
    model = load_model(MODEL_PATH)

    # Start Flask sensor receiver in background thread
    sensor_thread = threading.Thread(target=start_sensor_server, daemon=True)
    sensor_thread.start()
    logger.info("Sensor receiver started in background.")

    # Initialize face landmark detector
    landmark_detector = FaceLandmarkDetector()

    # Open camera
    cap = cv2.VideoCapture(CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
    cap.set(cv2.CAP_PROP_FPS, TARGET_FPS)

    if not cap.isOpened():
        logger.critical("Cannot open camera. Exiting.")
        return

    logger.info("Camera opened. Entering detection loop.")

    consecutive_alert_frames = 0
    frame_interval = 1.0 / TARGET_FPS

    try:
        while True:
            loop_start = time.time()

            ret, frame = cap.read()
            if not ret:
                logger.warning("Failed to read frame from camera.")
                time.sleep(0.1)
                continue

            # ── Step 1: Extract face landmarks ────────────────────────────────
            landmarks = landmark_detector.detect(frame)

            if landmarks is None:
                logger.debug("No face detected in frame.")
                clear_alert()
                consecutive_alert_frames = 0
                _sleep_until_next_frame(loop_start, frame_interval)
                continue

            # ── Step 2: Calculate EAR ─────────────────────────────────────────
            ear = calculate_ear(landmarks)

            # ── Step 3: Get latest ESP32 sensor data ──────────────────────────
            sensor_data = get_latest_sensor_data()
            # sensor_data is a dict: {"heart_rate": float, "spo2": float, ...}

            # ── Step 4: Combine features ──────────────────────────────────────
            features = combine_features(ear, sensor_data)

            # ── Step 5: Predict state ─────────────────────────────────────────
            state = predict_state(model, features)

            # ── Step 6: Alert logic ───────────────────────────────────────────
            if state in ("Drowsy", "Microsleep"):
                consecutive_alert_frames += 1
                if consecutive_alert_frames >= EAR_CONSEC_FRAMES:
                    trigger_alert(state)
                    log_event(logger, state, ear, sensor_data)
            else:
                consecutive_alert_frames = 0
                clear_alert()

            logger.debug(f"EAR={ear:.3f} | State={state} | Sensor={sensor_data}")

            _sleep_until_next_frame(loop_start, frame_interval)

    except KeyboardInterrupt:
        logger.info("Shutdown requested by user.")
    finally:
        cap.release()
        clear_alert()
        landmark_detector.close()
        logger.info("Resources released. System stopped.")


def _sleep_until_next_frame(loop_start: float, interval: float):
    """Busy-sleep to maintain target FPS without drifting."""
    elapsed = time.time() - loop_start
    remaining = interval - elapsed
    if remaining > 0:
        time.sleep(remaining)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    main()
