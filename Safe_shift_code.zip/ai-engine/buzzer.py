"""
alerts/buzzer.py — Buzzer and alert management module.

Controls a piezo buzzer wired to a Raspberry Pi GPIO pin.
Falls back gracefully on systems without RPi.GPIO (e.g., dev machines).

Wiring assumption:
    Buzzer positive → GPIO pin BUZZER_PIN (BCM numbering)
    Buzzer negative → GND

Alert levels:
    'Fatigue'    → short intermittent beeps
    'Drowsy'     → faster beeps
    'Microsleep' → continuous loud alert
"""

import time
import logging
import threading

logger = logging.getLogger("buzzer")

# ── GPIO configuration ────────────────────────────────────────────────────────

BUZZER_PIN = 17   # BCM GPIO17 (physical pin 11) — change as needed

# Alert patterns: (on_seconds, off_seconds, repeat_count)
ALERT_PATTERNS = {
    "Fatigue":    (0.3, 0.5, 2),
    "Drowsy":     (0.2, 0.2, 4),
    "Microsleep": (0.1, 0.05, 10),
}

# ── GPIO initialisation ───────────────────────────────────────────────────────

try:
    import RPi.GPIO as GPIO
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(BUZZER_PIN, GPIO.OUT, initial=GPIO.LOW)
    _GPIO_AVAILABLE = True
    logger.info(f"RPi.GPIO initialised. Buzzer on BCM pin {BUZZER_PIN}.")
except (ImportError, RuntimeError):
    _GPIO_AVAILABLE = False
    logger.warning("RPi.GPIO not available. Buzzer will run in simulation mode.")


# ── Internal state ────────────────────────────────────────────────────────────

_alert_active = False
_alert_lock   = threading.Lock()
_alert_thread: threading.Thread | None = None


# ── GPIO helpers ──────────────────────────────────────────────────────────────

def _buzzer_on():
    if _GPIO_AVAILABLE:
        GPIO.output(BUZZER_PIN, GPIO.HIGH)
    else:
        logger.debug("[SIM] Buzzer ON")


def _buzzer_off():
    if _GPIO_AVAILABLE:
        GPIO.output(BUZZER_PIN, GPIO.LOW)
    else:
        logger.debug("[SIM] Buzzer OFF")


# ── Alert runner (background thread) ─────────────────────────────────────────

def _run_alert(state: str):
    """Play the alert pattern for the given state. Stops when _alert_active is False."""
    global _alert_active

    on_t, off_t, repeats = ALERT_PATTERNS.get(state, (0.2, 0.2, 3))

    logger.info(f"Alert triggered: {state}")

    with _alert_lock:
        _alert_active = True

    while True:
        with _alert_lock:
            if not _alert_active:
                break
        for _ in range(repeats):
            with _alert_lock:
                if not _alert_active:
                    break
            _buzzer_on()
            time.sleep(on_t)
            _buzzer_off()
            time.sleep(off_t)
        time.sleep(0.1)   # Brief pause between pattern cycles

    _buzzer_off()
    logger.debug(f"Alert thread for '{state}' finished.")


# ── Public interface ──────────────────────────────────────────────────────────

def trigger_alert(state: str):
    """
    Start (or continue) an alert for the given fatigue state.
    If an alert is already running for the same state, this is a no-op.

    Args:
        state: One of 'Fatigue', 'Drowsy', 'Microsleep'.
    """
    global _alert_thread, _alert_active

    with _alert_lock:
        already_running = _alert_active

    if already_running:
        return  # Don't restart; let the existing pattern run

    _alert_thread = threading.Thread(
        target=_run_alert, args=(state,), daemon=True, name="buzzer-alert"
    )
    _alert_thread.start()


def clear_alert():
    """Stop any active alert and silence the buzzer immediately."""
    global _alert_active

    with _alert_lock:
        _alert_active = False

    _buzzer_off()


def cleanup_gpio():
    """
    Release GPIO resources on shutdown.
    Call this from app.py's finally block if running on real hardware.
    """
    clear_alert()
    if _GPIO_AVAILABLE:
        GPIO.cleanup()
        logger.info("GPIO cleaned up.")
