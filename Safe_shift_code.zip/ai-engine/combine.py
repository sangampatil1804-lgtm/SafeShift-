"""
fusion/combine.py — Feature fusion module.

Combines vision-based EAR features with ESP32 sensor readings into a
single normalised feature vector for KNN classification.

Feature vector layout (7 features):
    [0] ear          — Eye Aspect Ratio          (0.0 – 0.5)
    [1] heart_rate   — BPM, normalised           (0 – 200 BPM → 0.0 – 1.0)
    [2] spo2         — SpO₂ %, normalised        (80 – 100 %  → 0.0 – 1.0)
    [3] accel_x      — Clipped & normalised      (-2g–+2g     → 0.0 – 1.0)
    [4] accel_y      — Clipped & normalised
    [5] accel_z      — Clipped & normalised
    [6] head_motion  — Derived magnitude of accel (0.0 – 1.0)

All values are clipped to [0, 1] before returning.
"""

import math
import logging
from typing import Optional

logger = logging.getLogger("fusion")

# ── Normalisation bounds (tune to your sensor hardware) ───────────────────────

HR_MIN,   HR_MAX   = 30.0,  200.0   # BPM
SPO2_MIN, SPO2_MAX = 80.0,  100.0   # Percent
ACCEL_MIN          = -19.62         # m/s² → -2g
ACCEL_MAX          =  19.62         # m/s² → +2g


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Clamp a float to [lo, hi]."""
    return max(lo, min(hi, value))


def _normalise(value: float, lo: float, hi: float) -> float:
    """Min-max normalise value to [0, 1]. Returns 0.5 on zero-range."""
    if hi == lo:
        return 0.5
    return _clamp((value - lo) / (hi - lo))


def combine_features(ear: float, sensor_data: Optional[dict]) -> list:
    """
    Build the feature vector for KNN inference.

    Args:
        ear:         Eye Aspect Ratio (float, already computed).
        sensor_data: Dict from esp_receiver.get_latest_sensor_data().
                     Can be None or missing keys — defaults to 0.0.

    Returns:
        List of 7 normalised floats, ready for model.predict([features]).
    """
    if sensor_data is None:
        sensor_data = {}

    # Raw sensor values (fall back gracefully)
    heart_rate = float(sensor_data.get("heart_rate", 0.0))
    spo2       = float(sensor_data.get("spo2",       0.0))
    accel_x    = float(sensor_data.get("accel_x",    0.0))
    accel_y    = float(sensor_data.get("accel_y",    0.0))
    accel_z    = float(sensor_data.get("accel_z",    0.0))

    # Derived head-motion magnitude (Euclidean norm of acceleration vector)
    # Useful for detecting head nodding / jerks
    motion_mag = math.sqrt(accel_x**2 + accel_y**2 + accel_z**2)

    # Normalise all features
    ear_norm    = _clamp(ear, 0.0, 0.5) / 0.5              # EAR max is ~0.5
    hr_norm     = _normalise(heart_rate, HR_MIN,   HR_MAX)
    spo2_norm   = _normalise(spo2,       SPO2_MIN, SPO2_MAX)
    ax_norm     = _normalise(accel_x,    ACCEL_MIN, ACCEL_MAX)
    ay_norm     = _normalise(accel_y,    ACCEL_MIN, ACCEL_MAX)
    az_norm     = _normalise(accel_z,    ACCEL_MIN, ACCEL_MAX)
    motion_norm = _normalise(motion_mag, 0.0, ACCEL_MAX * math.sqrt(3))

    features = [
        round(ear_norm,    4),
        round(hr_norm,     4),
        round(spo2_norm,   4),
        round(ax_norm,     4),
        round(ay_norm,     4),
        round(az_norm,     4),
        round(motion_norm, 4),
    ]

    logger.debug(f"Feature vector: {features}")
    return features


def feature_names() -> list:
    """Return human-readable feature names (for debugging / model training)."""
    return ["ear", "heart_rate", "spo2", "accel_x", "accel_y", "accel_z", "head_motion"]
