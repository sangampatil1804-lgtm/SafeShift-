"""
detector/ear.py — Eye Aspect Ratio (EAR) calculation module.

EAR is the primary vision-based fatigue indicator.
Formula from Soukupová & Čech (2016):
    EAR = (||p2-p6|| + ||p3-p5||) / (2 * ||p1-p4||)

Landmark point order (per eye, 6 points):
    p1=outer corner, p2=upper-outer, p3=upper-inner,
    p4=inner corner, p5=lower-inner, p6=lower-outer
"""

import math
import logging
from typing import Optional

logger = logging.getLogger("ear")

# EAR thresholds (tune with your own dataset)
EAR_NORMAL_MIN    = 0.25   # Fully open eye
EAR_FATIGUE_MAX   = 0.25   # Starting to droop
EAR_DROWSY_MAX    = 0.20   # Significant closure
EAR_MICROSLEEP_MAX = 0.15  # Nearly / fully closed


def _euclidean(p1: tuple, p2: tuple) -> float:
    """Return the Euclidean distance between two (x, y) points."""
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)


def eye_aspect_ratio(eye_points: list) -> float:
    """
    Compute EAR for a single eye.

    Args:
        eye_points: List of 6 (x, y) pixel tuples in landmark order:
                    [p1, p2, p3, p4, p5, p6]

    Returns:
        EAR float value. Returns 0.0 on invalid input.
    """
    if len(eye_points) != 6:
        logger.error(f"Expected 6 eye points, got {len(eye_points)}.")
        return 0.0

    try:
        # Vertical distances
        v1 = _euclidean(eye_points[1], eye_points[5])  # p2 <-> p6
        v2 = _euclidean(eye_points[2], eye_points[4])  # p3 <-> p5

        # Horizontal distance
        h  = _euclidean(eye_points[0], eye_points[3])  # p1 <-> p4

        if h == 0:
            logger.warning("Horizontal eye distance is zero; returning 0.0.")
            return 0.0

        ear = (v1 + v2) / (2.0 * h)
        return round(ear, 4)

    except Exception as e:
        logger.error(f"EAR calculation error: {e}")
        return 0.0


def calculate_ear(landmarks: dict) -> float:
    """
    Calculate the average EAR across both eyes from a landmarks dict.

    Args:
        landmarks: dict returned by FaceLandmarkDetector.detect(),
                   with keys 'left_eye' and 'right_eye'.

    Returns:
        Average EAR (float). Returns 0.3 (safe default) on missing data.
    """
    if not landmarks:
        logger.debug("No landmarks provided to calculate_ear.")
        return 0.3   # Safe fallback (open eye value)

    left_ear  = eye_aspect_ratio(landmarks.get("left_eye",  []))
    right_ear = eye_aspect_ratio(landmarks.get("right_eye", []))

    avg_ear = (left_ear + right_ear) / 2.0
    logger.debug(f"L-EAR={left_ear:.4f}, R-EAR={right_ear:.4f}, Avg={avg_ear:.4f}")
    return round(avg_ear, 4)


def classify_ear(ear: float) -> str:
    """
    Map an EAR value to a human-readable fatigue label.
    Used for standalone EAR-only classification or debugging.

    Args:
        ear: EAR float value.

    Returns:
        One of: 'Normal', 'Fatigue', 'Drowsy', 'Microsleep'.
    """
    if ear <= EAR_MICROSLEEP_MAX:
        return "Microsleep"
    elif ear <= EAR_DROWSY_MAX:
        return "Drowsy"
    elif ear <= EAR_FATIGUE_MAX:
        return "Fatigue"
    return "Normal"
