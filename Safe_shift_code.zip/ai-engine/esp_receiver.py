"""
sensor/esp_receiver.py — Flask API server that receives data from ESP32 sensors.

The ESP32 POSTs JSON payloads to /sensor/data.
Data is stored in a thread-safe in-memory buffer consumed by the main pipeline.

Expected ESP32 payload (example):
    {
        "heart_rate": 72.5,
        "spo2":       97.0,
        "accel_x":    0.01,
        "accel_y":   -0.02,
        "accel_z":    9.81,
        "timestamp":  1715000000
    }

Run via: threading.Thread(target=start_sensor_server, daemon=True).start()
"""

import threading
import logging
import time

from flask import Flask, request, jsonify

logger = logging.getLogger("esp_receiver")

# ── Shared state ──────────────────────────────────────────────────────────────

_lock         = threading.Lock()
_latest_data  = {
    "heart_rate": 0.0,
    "spo2":       0.0,
    "accel_x":    0.0,
    "accel_y":    0.0,
    "accel_z":    0.0,
    "timestamp":  0,
}
_last_received = 0.0   # Unix timestamp of last successful POST
STALE_THRESHOLD = 5.0  # Seconds before sensor data is considered stale

# ── Flask app ─────────────────────────────────────────────────────────────────

_flask_app = Flask(__name__)

# Suppress Flask's default access log noise
log = logging.getLogger("werkzeug")
log.setLevel(logging.ERROR)


@_flask_app.route("/sensor/data", methods=["POST"])
def receive_sensor_data():
    """Endpoint for ESP32 to POST sensor readings."""
    global _latest_data, _last_received

    payload = request.get_json(silent=True)
    if payload is None:
        logger.warning("Received non-JSON or empty payload.")
        return jsonify({"status": "error", "message": "Invalid JSON"}), 400

    with _lock:
        _latest_data = {
            "heart_rate": float(payload.get("heart_rate", 0.0)),
            "spo2":       float(payload.get("spo2",       0.0)),
            "accel_x":    float(payload.get("accel_x",    0.0)),
            "accel_y":    float(payload.get("accel_y",    0.0)),
            "accel_z":    float(payload.get("accel_z",    0.0)),
            "timestamp":  int(payload.get("timestamp",    0)),
        }
        _last_received = time.time()

    logger.debug(f"Sensor data updated: {_latest_data}")
    return jsonify({"status": "ok"}), 200


@_flask_app.route("/sensor/status", methods=["GET"])
def sensor_status():
    """Health-check endpoint — returns latest data and staleness flag."""
    with _lock:
        data      = dict(_latest_data)
        stale     = (time.time() - _last_received) > STALE_THRESHOLD
        age       = round(time.time() - _last_received, 2)

    return jsonify({
        "status":      "stale" if stale else "live",
        "age_seconds": age,
        "data":        data,
    }), 200


# ── Public interface ──────────────────────────────────────────────────────────

def start_sensor_server(host: str = "0.0.0.0", port: int = 5050):
    """
    Start the Flask sensor receiver.
    Designed to be called inside a daemon thread from app.py.

    Args:
        host: Interface to bind (0.0.0.0 = all interfaces).
        port: TCP port (default 5050; keep separate from any other service).
    """
    logger.info(f"Sensor receiver starting on {host}:{port}...")
    try:
        _flask_app.run(host=host, port=port, debug=False, use_reloader=False)
    except Exception as e:
        logger.error(f"Sensor server error: {e}")


def get_latest_sensor_data() -> dict:
    """
    Return the most recent sensor data snapshot (thread-safe).

    Returns:
        dict with heart_rate, spo2, accel_x/y/z, timestamp.
        Values are 0.0 if ESP32 has not sent data yet.
    """
    with _lock:
        return dict(_latest_data)


def is_sensor_data_fresh() -> bool:
    """Return True if a sensor update was received within STALE_THRESHOLD seconds."""
    return (time.time() - _last_received) <= STALE_THRESHOLD
