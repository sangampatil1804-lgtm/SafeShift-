"""
detector/landmarks.py — MediaPipe-based face landmark detection module.

Wraps MediaPipe FaceMesh to extract 468 3D facial landmarks from a BGR frame.
Designed for low-latency inference on Raspberry Pi 4.
"""

import cv2
import mediapipe as mp
import logging
from typing import Optional

logger = logging.getLogger("landmarks")


class FaceLandmarkDetector:
    """
    Wraps MediaPipe FaceMesh for single-face landmark extraction.

    Usage:
        detector = FaceLandmarkDetector()
        landmarks = detector.detect(bgr_frame)
        detector.close()
    """

    # MediaPipe landmark indices for left and right eyes
    LEFT_EYE_INDICES  = [362, 385, 387, 263, 373, 380]
    RIGHT_EYE_INDICES = [33,  160, 158, 133, 153, 144]

    def __init__(
        self,
        max_num_faces: int = 1,
        refine_landmarks: bool = False,   # Keep False for RPi4 speed
        min_detection_confidence: float = 0.5,
        min_tracking_confidence: float = 0.5,
    ):
        """
        Initialise MediaPipe FaceMesh.

        Args:
            max_num_faces:              Number of faces to track (1 for driver monitoring).
            refine_landmarks:           Enable iris refinement (expensive; off by default).
            min_detection_confidence:   Confidence threshold for face detection.
            min_tracking_confidence:    Confidence threshold for landmark tracking.
        """
        self._mp_face_mesh = mp.solutions.face_mesh
        self._face_mesh = self._mp_face_mesh.FaceMesh(
            max_num_faces=max_num_faces,
            refine_landmarks=refine_landmarks,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )
        logger.info("FaceLandmarkDetector initialised.")

    def detect(self, bgr_frame) -> Optional[dict]:
        """
        Run landmark detection on a single BGR frame.

        Args:
            bgr_frame: OpenCV BGR numpy array (H x W x 3).

        Returns:
            dict with keys 'left_eye' and 'right_eye', each a list of
            (x, y) pixel tuples for the 6 EAR landmark points.
            Returns None if no face is detected.
        """
        if bgr_frame is None:
            logger.warning("Received None frame.")
            return None

        h, w = bgr_frame.shape[:2]

        # MediaPipe expects RGB
        rgb_frame = cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2RGB)
        rgb_frame.flags.writeable = False  # Performance hint

        try:
            results = self._face_mesh.process(rgb_frame)
        except Exception as e:
            logger.error(f"MediaPipe processing error: {e}")
            return None

        if not results.multi_face_landmarks:
            return None

        face = results.multi_face_landmarks[0]  # First (and only) face

        def _extract(indices):
            pts = []
            for idx in indices:
                lm = face.landmark[idx]
                pts.append((int(lm.x * w), int(lm.y * h)))
            return pts

        return {
            "left_eye":  _extract(self.LEFT_EYE_INDICES),
            "right_eye": _extract(self.RIGHT_EYE_INDICES),
            "raw":       face.landmark,   # Full 468-point cloud for future use
        }

    def close(self):
        """Release MediaPipe resources."""
        self._face_mesh.close()
        logger.info("FaceLandmarkDetector closed.")
