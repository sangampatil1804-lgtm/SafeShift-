"""
logs/logger.py — Centralised logging setup and event logging utilities.

Creates rotating file logs under logs/fatigue_events.log and also
streams to stdout for real-time monitoring via SSH or serial console.

Log format:
    2025-01-15 14:32:01,123 | INFO | app | EAR=0.187 | State=Drowsy | HR=68.0
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from typing import Optional

# ── Constants ─────────────────────────────────────────────────────────────────

LOG_DIR      = os.path.join(os.path.dirname(__file__))   # logs/ directory
LOG_FILE     = os.path.join(LOG_DIR, "fatigue_events.log")
MAX_BYTES    = 5 * 1024 * 1024   # 5 MB per file
BACKUP_COUNT = 3                  # Keep 3 rotated files


# ── Setup ─────────────────────────────────────────────────────────────────────

def setup_logger(
    name:     str,
    level:    int  = logging.INFO,
    log_file: str  = LOG_FILE,
) -> logging.Logger:
    """
    Create and configure a named logger with rotating file + console handlers.

    Args:
        name:     Logger name (e.g. 'app', 'ear', 'fusion').
        level:    Logging level (default: INFO).
        log_file: Path to rotating log file.

    Returns:
        Configured logging.Logger instance.
    """
    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers if called multiple times
    if logger.handlers:
        return logger

    logger.setLevel(level)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-12s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # ── Console handler ───────────────────────────────────────────────────────
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # ── Rotating file handler ─────────────────────────────────────────────────
    try:
        os.makedirs(os.path.dirname(os.path.abspath(log_file)), exist_ok=True)
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=MAX_BYTES,
            backupCount=BACKUP_COUNT,
            encoding="utf-8",
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except OSError as e:
        logger.warning(f"Could not create file handler for '{log_file}': {e}")

    return logger


# ── Event logging ─────────────────────────────────────────────────────────────

def log_event(
    logger:      logging.Logger,
    state:       str,
    ear:         float,
    sensor_data: Optional[dict] = None,
):
    """
    Log a structured fatigue event with all relevant telemetry.

    Args:
        logger:      Logger instance (from setup_logger).
        state:       Predicted state string ('Normal', 'Fatigue', etc.).
        ear:         Current Eye Aspect Ratio.
        sensor_data: Latest sensor readings dict (optional).
    """
    sd = sensor_data or {}

    hr     = sd.get("heart_rate", "N/A")
    spo2   = sd.get("spo2",       "N/A")
    accel  = (
        f"{sd.get('accel_x', 0):.2f},"
        f"{sd.get('accel_y', 0):.2f},"
        f"{sd.get('accel_z', 0):.2f}"
    )

    log_line = (
        f"STATE={state} | "
        f"EAR={ear:.4f} | "
        f"HR={hr} | "
        f"SpO2={spo2} | "
        f"ACCEL=[{accel}]"
    )

    if state == "Microsleep":
        logger.critical(log_line)
    elif state in ("Drowsy", "Fatigue"):
        logger.warning(log_line)
    else:
        logger.info(log_line)
