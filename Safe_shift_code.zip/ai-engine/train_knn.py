"""
train_knn.py — Offline KNN model training script (placeholder).

Run this on a development machine with labelled data to produce knn_model.pkl.
Copy the resulting .pkl to the Raspberry Pi alongside app.py.

Usage:
    python train_knn.py --data dataset.csv --output knn_model.pkl

Dataset CSV expected columns (matches fusion/combine.py feature vector):
    ear, heart_rate, spo2, accel_x, accel_y, accel_z, head_motion, label

Labels:
    0 = Normal
    1 = Fatigue
    2 = Drowsy
    3 = Microsleep
"""

import argparse
import pickle
import logging
import os

import numpy as np

logger = logging.getLogger("train_knn")
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

# ── Optional heavy deps — not required on RPi at runtime ─────────────────────
try:
    import pandas as pd
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import classification_report
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False
    logger.warning("scikit-learn / pandas not installed. Training unavailable.")


FEATURE_COLS = ["ear", "heart_rate", "spo2", "accel_x", "accel_y", "accel_z", "head_motion"]
LABEL_COL    = "label"
LABEL_NAMES  = ["Normal", "Fatigue", "Drowsy", "Microsleep"]


def train(data_path: str, output_path: str, n_neighbors: int = 5):
    """
    Load dataset, train KNN, evaluate, and save model.

    Args:
        data_path:   Path to labelled CSV file.
        output_path: Where to save the pickled KNN model.
        n_neighbors: K for KNN (default 5).
    """
    if not _SKLEARN_AVAILABLE:
        logger.error("scikit-learn is required for training. Install it with:")
        logger.error("  pip install scikit-learn pandas")
        return

    if not os.path.exists(data_path):
        logger.error(f"Dataset not found: {data_path}")
        return

    logger.info(f"Loading dataset from {data_path}...")
    df = pd.read_csv(data_path)

    # Validate columns
    missing = [c for c in FEATURE_COLS + [LABEL_COL] if c not in df.columns]
    if missing:
        logger.error(f"Missing columns in dataset: {missing}")
        return

    X = df[FEATURE_COLS].values.astype(np.float32)
    y = df[LABEL_COL].values.astype(int)

    logger.info(f"Dataset: {len(X)} samples, class distribution: {np.bincount(y)}")

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # KNN — no scaler needed since features are already normalised by combine.py
    knn = KNeighborsClassifier(
        n_neighbors=n_neighbors,
        metric="euclidean",
        weights="distance",
        algorithm="ball_tree",   # Efficient for low-dim, small datasets
        n_jobs=-1,
    )
    knn.fit(X_train, y_train)

    # Evaluate
    y_pred = knn.predict(X_test)
    report = classification_report(y_test, y_pred, target_names=LABEL_NAMES)
    logger.info(f"Classification report:\n{report}")

    # Save model
    with open(output_path, "wb") as f:
        pickle.dump(knn, f)
    logger.info(f"Model saved to {output_path}")


def create_dummy_model(output_path: str):
    """
    Create and save a dummy KNN model with synthetic data.
    Useful for testing the pipeline without real labelled data.
    """
    if not _SKLEARN_AVAILABLE:
        logger.error("scikit-learn required.")
        return

    logger.info("Generating dummy model with synthetic data...")

    np.random.seed(42)
    n_per_class = 50
    X_list, y_list = [], []

    # Rough synthetic distributions per class
    class_params = {
        0: {"ear_mean": 0.65, "hr": 0.5, "spo2": 0.9},   # Normal
        1: {"ear_mean": 0.45, "hr": 0.45, "spo2": 0.85},  # Fatigue
        2: {"ear_mean": 0.30, "hr": 0.40, "spo2": 0.80},  # Drowsy
        3: {"ear_mean": 0.10, "hr": 0.35, "spo2": 0.75},  # Microsleep
    }
    for label, params in class_params.items():
        X_class = np.random.normal(
            loc=[params["ear_mean"], params["hr"], params["spo2"], 0.5, 0.5, 0.5, 0.1],
            scale=0.05,
            size=(n_per_class, 7),
        ).clip(0, 1)
        X_list.append(X_class)
        y_list.extend([label] * n_per_class)

    X = np.vstack(X_list).astype(np.float32)
    y = np.array(y_list, dtype=int)

    knn = KNeighborsClassifier(n_neighbors=5, metric="euclidean", weights="distance")
    knn.fit(X, y)

    with open(output_path, "wb") as f:
        pickle.dump(knn, f)
    logger.info(f"Dummy model saved to {output_path}")


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train KNN fatigue detection model")
    parser.add_argument("--data",    type=str, default="dataset.csv",  help="Path to CSV dataset")
    parser.add_argument("--output",  type=str, default="knn_model.pkl", help="Output model path")
    parser.add_argument("--k",       type=int, default=5,               help="KNN neighbours")
    parser.add_argument("--dummy",   action="store_true",               help="Generate dummy model (no data needed)")
    args = parser.parse_args()

    if args.dummy:
        create_dummy_model(args.output)
    else:
        train(args.data, args.output, n_neighbors=args.k)
