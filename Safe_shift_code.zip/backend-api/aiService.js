'use strict';

/**
 * Derive a human-readable fatigue label from a numeric score.
 * @param {number} score  0.0 – 1.0
 * @returns {'alert'|'drowsy'|'sleeping'}
 */
function scoreToLabel(score) {
  if (score >= 0.75) return 'sleeping';
  if (score >= 0.45) return 'drowsy';
  return 'alert';
}

/**
 * Map a fatigue label to an alert severity level.
 * @param {'alert'|'drowsy'|'sleeping'} label
 * @returns {'low'|'medium'|'high'|'critical'}
 */
function labelToSeverity(label) {
  const map = {
    alert:    'low',
    drowsy:   'high',
    sleeping: 'critical',
  };
  return map[label] ?? 'medium';
}

/**
 * Build a human-readable alert message.
 * @param {object} params
 * @param {string} params.deviceId
 * @param {string} params.label
 * @param {number} params.score
 * @param {string} [params.operatorId]
 */
function buildAlertMessage({ deviceId, label, score, operatorId }) {
  const pct = Math.round(score * 100);
  const who = operatorId ? `operator ${operatorId}` : `device ${deviceId}`;
  const messages = {
    alert:    `${who} is alert (fatigue score ${pct}%).`,
    drowsy:   `⚠️  ${who} is showing signs of drowsiness (fatigue score ${pct}%). Immediate attention recommended.`,
    sleeping: `🚨 CRITICAL — ${who} appears to be sleeping (fatigue score ${pct}%). Halt operations NOW.`,
  };
  return messages[label] ?? `Fatigue event on ${who} (score ${pct}%).`;
}

/**
 * Validate that the prediction payload from the AI engine is well-formed.
 * Returns { valid: boolean, errors: string[] }
 */
function validatePredictionPayload(body) {
  const errors = [];
  if (!body.device_id || typeof body.device_id !== 'string') {
    errors.push('device_id is required and must be a string');
  }
  if (typeof body.fatigue_score !== 'number' || body.fatigue_score < 0 || body.fatigue_score > 1) {
    errors.push('fatigue_score is required and must be a number between 0 and 1');
  }
  return { valid: errors.length === 0, errors };
}

module.exports = { scoreToLabel, labelToSeverity, buildAlertMessage, validatePredictionPayload };
