'use strict';

const { query, execute, queryOne } = require('../services/dbService');
const { createError } = require('../middleware/errorMiddleware');

/**
 * GET /api/alerts
 *
 * Query params:
 *   device_id   filter by device
 *   severity    low | medium | high | critical
 *   acknowledged 0 | 1
 *   limit       default 50, max 200
 *   offset      default 0
 */
async function listAlerts(req, res, next) {
  try {
    const { device_id, severity, acknowledged, limit = 50, offset = 0 } = req.query;

    const safeLimit  = Math.min(parseInt(limit, 10) || 50, 200);
    const safeOffset = parseInt(offset, 10) || 0;

    const conditions = [];
    const params = [];

    if (device_id) { conditions.push('a.device_id = ?');    params.push(device_id); }
    if (severity)  { conditions.push('a.severity = ?');     params.push(severity); }
    if (acknowledged !== undefined) {
      conditions.push('a.acknowledged = ?');
      params.push(acknowledged === '1' || acknowledged === 'true' ? 1 : 0);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const rows = await query(
      `SELECT a.id, a.prediction_id, a.device_id, a.severity, a.message,
              a.acknowledged, a.acknowledged_by, a.created_at,
              p.fatigue_score, p.fatigue_label, p.operator_id
       FROM alerts a
       JOIN predictions p ON p.id = a.prediction_id
       ${where}
       ORDER BY a.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, safeLimit, safeOffset]
    );

    const [{ total }] = await query(
      `SELECT COUNT(*) AS total FROM alerts a ${where}`,
      params
    );

    res.json({ success: true, data: rows, meta: { total, limit: safeLimit, offset: safeOffset } });
  } catch (err) {
    next(err);
  }
}

/**
 * PATCH /api/alerts/:id/acknowledge
 */
async function acknowledgeAlert(req, res, next) {
  try {
    const alertId = parseInt(req.params.id, 10);
    const alert = await queryOne('SELECT id FROM alerts WHERE id = ?', [alertId]);
    if (!alert) throw createError('Alert not found', 404);

    await execute(
      'UPDATE alerts SET acknowledged = 1, acknowledged_by = ? WHERE id = ?',
      [req.user.id, alertId]
    );

    res.json({ success: true, message: 'Alert acknowledged' });
  } catch (err) {
    next(err);
  }
}

module.exports = { listAlerts, acknowledgeAlert };
