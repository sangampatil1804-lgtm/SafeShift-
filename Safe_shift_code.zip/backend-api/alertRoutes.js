'use strict';

const { Router } = require('express');
const { authenticate, authorize } = require('../middleware/authMiddleware');
const { listAlerts, acknowledgeAlert } = require('../controllers/alertController');

const router = Router();

// All alert routes require a valid JWT
router.use(authenticate);

// GET /api/alerts
router.get('/', listAlerts);

// PATCH /api/alerts/:id/acknowledge  — operators and admins only
router.patch('/:id/acknowledge', authorize('admin', 'operator'), acknowledgeAlert);

module.exports = router;
