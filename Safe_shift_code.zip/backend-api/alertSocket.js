'use strict';

const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

let io;

/**
 * Initialize Socket.IO with the HTTP server.
 * Called once from server.js.
 */
function init(httpServer) {
  const { Server } = require('socket.io');

  io = new Server(httpServer, {
    cors: {
      origin: (process.env.CORS_ORIGINS || '').split(',').map((o) => o.trim()),
      methods: ['GET', 'POST'],
      credentials: true,
    },
    pingInterval: 25000,
    pingTimeout: 60000,
  });

  // ── Authentication middleware ──────────────────────────────────────────────
  io.use((socket, next) => {
    const token =
      socket.handshake.auth?.token ||
      socket.handshake.headers?.authorization?.replace('Bearer ', '');

    if (!token) return next(new Error('Authentication required'));

    try {
      socket.user = jwt.verify(token, process.env.JWT_SECRET);
      next();
    } catch {
      next(new Error('Invalid or expired token'));
    }
  });

  // ── Connection handler ─────────────────────────────────────────────────────
  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id} (user=${socket.user?.email})`);

    // Clients can subscribe to a specific device room
    socket.on('subscribe:device', (deviceId) => {
      if (typeof deviceId === 'string' && deviceId.trim()) {
        socket.join(`device:${deviceId.trim()}`);
        logger.debug(`Socket ${socket.id} joined device:${deviceId}`);
      }
    });

    socket.on('unsubscribe:device', (deviceId) => {
      socket.leave(`device:${deviceId}`);
    });

    socket.on('disconnect', (reason) => {
      logger.info(`Socket disconnected: ${socket.id} — ${reason}`);
    });
  });

  logger.info('Socket.IO initialized');
  return io;
}

/**
 * Return the initialized io instance (used by controllers).
 */
function getIO() {
  if (!io) throw new Error('Socket.IO has not been initialized. Call init(httpServer) first.');
  return io;
}

module.exports = { init, getIO };
