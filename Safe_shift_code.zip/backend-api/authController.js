'use strict';

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const { queryOne, execute } = require('../services/dbService');
const { createError } = require('../middleware/errorMiddleware');
const logger = require('../utils/logger');

const SALT_ROUNDS = 12;

/**
 * POST /api/auth/register
 */
async function register(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return next(errors.array());

    const { name, email, password, role = 'operator' } = req.body;

    const existing = await queryOne('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) throw createError('Email is already registered', 409);

    const hash = await bcrypt.hash(password, SALT_ROUNDS);
    const result = await execute(
      'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [name, email, hash, role]
    );

    logger.info(`New user registered: ${email} (id=${result.insertId})`);
    res.status(201).json({ success: true, message: 'Registration successful', data: { id: result.insertId } });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/login
 */
async function login(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return next(errors.array());

    const { email, password } = req.body;

    const user = await queryOne(
      'SELECT id, name, email, password_hash, role FROM users WHERE email = ?',
      [email]
    );
    if (!user) throw createError('Invalid credentials', 401);

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) throw createError('Invalid credentials', 401);

    const payload = { id: user.id, name: user.name, email: user.email, role: user.role };
    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '8h',
    });

    logger.info(`User logged in: ${email}`);
    res.json({
      success: true,
      data: {
        token,
        user: payload,
      },
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login };
