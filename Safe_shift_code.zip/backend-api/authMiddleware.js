'use strict';

const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

/**
 * Verify the Bearer JWT in the Authorization header.
 * Attaches the decoded payload to req.user on success.
 */
function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Authorization header missing or malformed' });
  }

  const token = authHeader.slice(7);

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'Token expired' });
    }
    logger.warn(`JWT verification failed: ${err.message}`);
    return res.status(401).json({ success: false, message: 'Invalid token' });
  }
}

/**
 * Role-based access control factory.
 * Usage: authorize('admin') or authorize(['admin', 'operator'])
 */
function authorize(...allowedRoles) {
  const roles = allowedRoles.flat();
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Unauthenticated' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Insufficient permissions' });
    }
    next();
  };
}

/**
 * Validate that incoming prediction requests include the shared AI-engine secret.
 */
function authenticateAiEngine(req, res, next) {
  const secret = req.headers['x-ai-secret'];
  if (!secret || secret !== process.env.AI_ENGINE_SECRET) {
    logger.warn(`Rejected AI engine request from ${req.ip} — bad or missing X-AI-Secret`);
    return res.status(401).json({ success: false, message: 'Invalid AI engine secret' });
  }
  next();
}

module.exports = { authenticate, authorize, authenticateAiEngine };
