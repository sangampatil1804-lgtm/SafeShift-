'use strict';

const { query, queryOne } = require('../services/dbService');

/**
 * GET /api/dashboard/live
 *
 * Returns the most recent prediction per device
 * plus summary statistics for the last 15 minutes.
 */
async function getLiveDashboard(req, res, next) {
  try {
    // Latest prediction per device
    const latestPerDevice = await query(`
      SELECT p1.device_id, p1.operator_id, p1.fatigue_score, p1.fatigue_label, p1.created_at
      FROM predictions p1
      INNER JOIN (
        SELECT device_id, MAX(created_at) AS max_ts
        FROM predictions
        WHERE created_at >= NOW() - INTERVAL 15 MINUTE
        GROUP BY device_id
      ) p2 ON p1.device_id = p2.device_id AND p1.created_at = p2.max_ts
      ORDER BY p1.fatigue_score DESC
    `);

    // Alert summary (last 15 min, unacknowledged)
    const alertSummary = await query(`
      SELECT severity, COUNT(*) AS count
      FROM alerts
      WHERE created_at >= NOW() - INTERVAL 15 MINUTE AND acknowledged = 0
      GROUP BY severity
    `);

    // Overall counts
    const totals = await queryOne(`
      SELECT
        COUNT(*) AS total_predictions,
        SUM(CASE WHEN fatigue_label = 'drowsy'   THEN 1 ELSE 0 END) AS drowsy_count,
        SUM(CASE WHEN fatigue_label = 'sleeping' THEN 1 ELSE 0 END) AS sleeping_count,
        AVG(fatigue_score) AS avg_fatigue_score
      FROM predictions
      WHERE created_at >= NOW() - INTERVAL 15 MINUTE
    `);

    res.json({
      success: true,
      data: {
        window: '15m',
        devices: latestPerDevice,
        alert_summary: alertSummary,
        totals,
        generated_at: new Date().toISOString(),
      },
    });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/dashboard/history
 *
 * Query params:
 *   device_id   filter
 *   from        ISO datetime (default: 24h ago)
 *   to          ISO datetime (default: now)
 *   interval    minute | hour (default: hour)
 *   limit       default 100, max 500
 *   offset      default 0
 */
async function getHistory(req, res, next) {
  try {
    const {
      device_id,
      from,
      to,
      interval = 'hour',
      limit = 100,
      offset = 0,
    } = req.query;

    const safeLimit  = Math.min(parseInt(limit, 10) || 100, 500);
    const safeOffset = parseInt(offset, 10) || 0;

    const fromTs = from ? new Date(from) : new Date(Date.now() - 86400 * 1000);
    const toTs   = to   ? new Date(to)   : new Date();

    if (isNaN(fromTs) || isNaN(toTs)) {
      return res.status(422).json({ success: false, message: 'Invalid from/to date' });
    }

    const timeFormat = interval === 'minute' ? '%Y-%m-%d %H:%i:00' : '%Y-%m-%d %H:00:00';

    const conditions = ['p.created_at BETWEEN ? AND ?'];
    const params     = [fromTs, toTs];

    if (device_id) { conditions.push('p.device_id = ?'); params.push(device_id); }

    const where = conditions.join(' AND ');

    // Time-bucketed aggregation
    const buckets = await query(
      `SELECT
         DATE_FORMAT(p.created_at, '${timeFormat}') AS bucket,
         p.device_id,
         COUNT(*) AS sample_count,
         AVG(p.fatigue_score) AS avg_score,
         MAX(p.fatigue_score) AS max_score,
         SUM(CASE WHEN p.fatigue_label = 'drowsy'   THEN 1 ELSE 0 END) AS drowsy_count,
         SUM(CASE WHEN p.fatigue_label = 'sleeping' THEN 1 ELSE 0 END) AS sleeping_count
       FROM predictions p
       WHERE ${where}
       GROUP BY bucket, p.device_id
       ORDER BY bucket DESC
       LIMIT ? OFFSET ?`,
      [...params, safeLimit, safeOffset]
    );

    // Raw predictions list (same window)
    const predictions = await query(
      `SELECT p.id, p.device_id, p.operator_id, p.fatigue_score, p.fatigue_label, p.created_at
       FROM predictions p
       WHERE ${where}
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, safeLimit, safeOffset]
    );

    res.json({ success: true, data: { buckets, predictions }, meta: { from: fromTs, to: toTs, interval } });
  } catch (err) {
    next(err);
  }
}

module.exports = { getLiveDashboard, getHistory };
