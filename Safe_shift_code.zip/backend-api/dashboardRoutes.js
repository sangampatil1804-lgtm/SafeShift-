'use strict';

const { Router } = require('express');
const { authenticate } = require('../middleware/authMiddleware');
const { getLiveDashboard, getHistory } = require('../controllers/dashboardController');

const router = Router();

router.use(authenticate);

// GET /api/dashboard/live
router.get('/live', getLiveDashboard);

// GET /api/dashboard/history
router.get('/history', getHistory);

module.exports = router;
