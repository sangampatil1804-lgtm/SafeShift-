'use strict';

const mysql = require('mysql2/promise');
const logger = require('../utils/logger');

let pool;

/**
 * Returns the singleton connection pool, creating it on first call.
 */
function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host: process.env.DB_HOST || '127.0.0.1',
      port: parseInt(process.env.DB_PORT, 10) || 3306,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT, 10) || 10,
      waitForConnections: true,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 30000,
      timezone: '+00:00',
    });

    logger.info('MySQL connection pool created');
  }
  return pool;
}

/**
 * Verify that the database is reachable on startup.
 */
async function testConnection() {
  const conn = await getPool().getConnection();
  logger.info(`MySQL connected — host: ${process.env.DB_HOST}, db: ${process.env.DB_NAME}`);
  conn.release();
}

/**
 * Run the DDL migrations required by this service.
 * Idempotent — uses CREATE TABLE IF NOT EXISTS.
 */
async function runMigrations() {
  const db = getPool();

  await db.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name          VARCHAR(120) NOT NULL,
      email         VARCHAR(180) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      role          ENUM('admin','operator','viewer') NOT NULL DEFAULT 'operator',
      created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS predictions (
      id              CHAR(36)     NOT NULL PRIMARY KEY,
      device_id       VARCHAR(80)  NOT NULL,
      operator_id     VARCHAR(80),
      fatigue_score   FLOAT        NOT NULL COMMENT '0.0 – 1.0',
      fatigue_label   ENUM('alert','drowsy','sleeping') NOT NULL,
      raw_payload     JSON,
      created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_device    (device_id),
      INDEX idx_created   (created_at),
      INDEX idx_label     (fatigue_label)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS alerts (
      id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      prediction_id CHAR(36)     NOT NULL,
      device_id     VARCHAR(80)  NOT NULL,
      severity      ENUM('low','medium','high','critical') NOT NULL,
      message       TEXT,
      acknowledged  TINYINT(1)   NOT NULL DEFAULT 0,
      acknowledged_by INT UNSIGNED,
      created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (prediction_id) REFERENCES predictions(id) ON DELETE CASCADE,
      INDEX idx_device   (device_id),
      INDEX idx_severity (severity),
      INDEX idx_ack      (acknowledged)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  logger.info('Database migrations applied successfully');
}

module.exports = { getPool, testConnection, runMigrations };
