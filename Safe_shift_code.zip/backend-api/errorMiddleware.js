'use strict';

const logger = require('../utils/logger');

/**
 * 404 handler — must be registered AFTER all routes.
 */
function notFound(req, res, _next) {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  });
}

/**
 * Global error handler — must be the last middleware (4 args).
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Validation errors from express-validator are rethrown as arrays
  if (Array.isArray(err)) {
    return res.status(422).json({ success: false, errors: err });
  }

  const statusCode = err.statusCode || err.status || 500;
  const isProd = process.env.NODE_ENV === 'production';

  if (statusCode >= 500) {
    logger.error(err);
  } else {
    logger.warn(`[${statusCode}] ${err.message}`);
  }

  res.status(statusCode).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(isProd ? {} : { stack: err.stack }),
  });
}

/**
 * Convenience: create an error with a custom HTTP status code.
 */
function createError(message, statusCode = 500) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

module.exports = { notFound, errorHandler, createError };
