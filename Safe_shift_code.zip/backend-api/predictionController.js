'use strict';

const { v4: uuidv4 } = require('uuid');
const { execute, withTransaction } = require('../services/dbService');
const { scoreToLabel, labelToSeverity, buildAlertMessage, validatePredictionPayload } = require('../services/aiService');
const { getIO } = require('../sockets/alertSocket');
const { createError } = require('../middleware/errorMiddleware');
const logger = require('../utils/logger');

/**
 * POST /api/predictions
 *
 * Expected body (from AI engine):
 * {
 *   device_id:     string   (required)
 *   fatigue_score: number   0.0 – 1.0  (required)
 *   operator_id:   string   (optional)
 *   metadata:      object   (optional — any extra data from edge device)
 * }
 */
async function receivePrediction(req, res, next) {
  try {
    const { valid, errors } = validatePredictionPayload(req.body);
    if (!valid) throw createError(`Validation failed: ${errors.join('; ')}`, 422);

    const { device_id, fatigue_score, operator_id = null, ...rest } = req.body;

    const fatigue_label = scoreToLabel(fatigue_score);
    const severity      = labelToSeverity(fatigue_label);
    const predictionId  = uuidv4();
    const message       = buildAlertMessage({ deviceId: device_id, label: fatigue_label, score: fatigue_score, operatorId: operator_id });

    let alertId;

    await withTransaction(async (conn) => {
      // 1. Store prediction
      await conn.execute(
        `INSERT INTO predictions (id, device_id, operator_id, fatigue_score, fatigue_label, raw_payload)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [predictionId, device_id, operator_id, fatigue_score, fatigue_label, JSON.stringify({ fatigue_score, operator_id, ...rest })]
      );

      // 2. Store alert (always — consumer decides which severities to surface)
      const [alertResult] = await conn.execute(
        `INSERT INTO alerts (prediction_id, device_id, severity, message) VALUES (?, ?, ?, ?)`,
        [predictionId, device_id, severity, message]
      );
      alertId = alertResult.insertId;
    });

    // 3. Emit realtime socket event
    const socketPayload = {
      alertId,
      predictionId,
      deviceId: device_id,
      operatorId: operator_id,
      fatigueScore: fatigue_score,
      fatigueLabel: fatigue_label,
      severity,
      message,
      timestamp: new Date().toISOString(),
    };

    getIO().emit('fatigue:alert', socketPayload);

    // High-severity events also get their own targeted room broadcast
    if (severity === 'critical' || severity === 'high') {
      getIO().to(`device:${device_id}`).emit('fatigue:critical', socketPayload);
    }

    logger.info(`Prediction received — device=${device_id} label=${fatigue_label} score=${fatigue_score}`);

    res.status(201).json({
      success: true,
      message: 'Prediction stored and alert emitted',
      data: { predictionId, alertId, fatigue_label, severity },
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { receivePrediction };
