'use strict';

const { Router } = require('express');
const { authenticateAiEngine } = require('../middleware/authMiddleware');
const { receivePrediction } = require('../controllers/predictionController');

const router = Router();

// POST /api/predictions  — secured by shared AI-engine secret (not a user JWT)
router.post('/', authenticateAiEngine, receivePrediction);

module.exports = router;
