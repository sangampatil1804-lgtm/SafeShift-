'use strict';

require('dotenv').config();

const http    = require('http');
const app     = require('./app');
const logger  = require('./utils/logger');
const { testConnection, runMigrations } = require('./config/db');
const { init: initSockets } = require('./sockets/alertSocket');

const PORT = parseInt(process.env.PORT, 10) || 4000;

async function bootstrap() {
  // 1. Verify DB connectivity
  await testConnection();

  // 2. Apply DDL migrations (idempotent)
  await runMigrations();

  // 3. Create HTTP server from Express app
  const server = http.createServer(app);

  // 4. Attach Socket.IO
  initSockets(server);

  // 5. Start listening
  server.listen(PORT, () => {
    logger.info(`🚀  Edge AI Fatigue Detection API running on port ${PORT} [${process.env.NODE_ENV || 'development'}]`);
  });

  // ── Graceful shutdown ────────────────────────────────────────────────────
  const shutdown = (signal) => {
    logger.info(`${signal} received — shutting down gracefully`);
    server.close(() => {
      logger.info('HTTP server closed');
      process.exit(0);
    });

    // Force-kill if still hanging after 10 s
    setTimeout(() => {
      logger.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10_000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT',  () => shutdown('SIGINT'));

  process.on('unhandledRejection', (reason) => {
    logger.error('Unhandled Promise Rejection:', reason);
  });

  process.on('uncaughtException', (err) => {
    logger.error('Uncaught Exception:', err);
    process.exit(1);
  });
}

bootstrap().catch((err) => {
  console.error('Bootstrap failed:', err);
  process.exit(1);
});
