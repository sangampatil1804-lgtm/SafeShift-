/**
 * config/db.js
 * MySQL connection pool configuration.
 * Uses mysql2/promise for async/await support across all models.
 *
 * Environment variables (set via .env or deployment secrets):
 *   DB_HOST      - MySQL host            (default: localhost)
 *   DB_PORT      - MySQL port            (default: 3306)
 *   DB_USER      - MySQL user            (default: root)
 *   DB_PASSWORD  - MySQL password
 *   DB_NAME      - Database name         (default: fatigue_detection)
 *   DB_POOL_MAX  - Max pool connections  (default: 10)
 */

"use strict";

require("dotenv").config();
const mysql = require("mysql2/promise");

// ---------------------------------------------------------------------------
// Pool singleton — shared across the entire process lifetime
// ---------------------------------------------------------------------------
const pool = mysql.createPool({
  host:               process.env.DB_HOST     || "localhost",
  port:               parseInt(process.env.DB_PORT || "3306", 10),
  user:               process.env.DB_USER     || "root",
  password:           process.env.DB_PASSWORD || "",
  database:           process.env.DB_NAME     || "fatigue_detection",
  waitForConnections: true,
  connectionLimit:    parseInt(process.env.DB_POOL_MAX || "10", 10),
  queueLimit:         0,          // unlimited queued requests
  timezone:           "Z",        // store/retrieve all dates in UTC
  charset:            "utf8mb4",
});

// ---------------------------------------------------------------------------
// Health-check helper — useful for startup probes and /healthz endpoints
// ---------------------------------------------------------------------------
async function testConnection() {
  let conn;
  try {
    conn = await pool.getConnection();
    await conn.ping();
    console.log("[db] MySQL connection pool ready.");
  } catch (err) {
    console.error("[db] Unable to reach MySQL:", err.message);
    throw err;
  } finally {
    if (conn) conn.release();
  }
}

module.exports = { pool, testConnection };
