/**
 * index.js
 * Public entry point for the database-service module.
 *
 * Consumers (e.g. a REST API server) import from here so they never need to
 * know the internal directory layout.
 *
 * Usage:
 *   const db = require('./database-service');
 *   await db.testConnection();
 *   const id = await db.workers.createWorker({ employee_id: 'E001', name: 'Alice' });
 */

"use strict";

const { pool, testConnection } = require("./config/db");

const workers     = require("./models/workers");
const sessions    = require("./models/sessions");
const predictions = require("./models/predictions");
const alerts      = require("./models/alerts");

const { storePrediction } = require("./services/storePrediction");

module.exports = {
  // Core pool — exposed for raw queries or transactions in the consuming app
  pool,
  testConnection,

  // Model namespaces
  workers,
  sessions,
  predictions,
  alerts,

  // High-level services
  storePrediction,
};
