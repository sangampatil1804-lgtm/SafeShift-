-- =============================================================================
-- migrations/schema.sql
-- Edge AI Fatigue Detection — full database schema
--
-- Engine   : MySQL 8.0+  (InnoDB for FK support and ACID guarantees)
-- Charset  : utf8mb4     (full Unicode including emoji in notes/messages)
-- Collation: utf8mb4_unicode_ci
--
-- Apply with:
--   mysql -u <user> -p <database> < migrations/schema.sql
-- =============================================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- Drop in reverse dependency order for clean re-runs
DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS predictions;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS workers;

-- =============================================================================
-- TABLE: workers
-- Represents a person monitored by the fatigue-detection system.
-- =============================================================================
CREATE TABLE workers (
  id           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  employee_id  VARCHAR(64)     NOT NULL COMMENT 'Unique badge/HR identifier',
  name         VARCHAR(255)    NOT NULL,
  department   VARCHAR(128)        NULL DEFAULT NULL,
  role         VARCHAR(128)        NULL DEFAULT NULL,
  is_active    TINYINT(1)      NOT NULL DEFAULT 1 COMMENT '1 = active, 0 = deactivated',
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_workers_employee_id (employee_id),
  KEY idx_workers_is_active (is_active)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Individuals being monitored for fatigue';


-- =============================================================================
-- TABLE: sessions
-- A continuous monitoring window (shift / stream) for one worker on one device.
-- =============================================================================
CREATE TABLE sessions (
  id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  worker_id   INT UNSIGNED    NOT NULL,
  device_id   VARCHAR(128)        NULL DEFAULT NULL COMMENT 'Edge camera / device ID',
  location    VARCHAR(255)        NULL DEFAULT NULL COMMENT 'Physical location label',
  status      ENUM(
                'active',
                'closed',
                'error'
              )               NOT NULL DEFAULT 'active',
  notes       TEXT                NULL DEFAULT NULL,
  started_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at    DATETIME            NULL DEFAULT NULL,
  created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_sessions_worker_id  (worker_id),
  KEY idx_sessions_status     (status),
  KEY idx_sessions_started_at (started_at),
  CONSTRAINT fk_sessions_worker
    FOREIGN KEY (worker_id) REFERENCES workers (id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Monitoring sessions (one per shift/stream)';


-- =============================================================================
-- TABLE: predictions
-- Single inference result emitted by the edge AI model.
-- =============================================================================
CREATE TABLE predictions (
  id               INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  session_id       INT UNSIGNED    NOT NULL,
  worker_id        INT UNSIGNED    NOT NULL COMMENT 'Denormalised for fast worker-level queries',
  label            VARCHAR(64)     NOT NULL COMMENT 'e.g. normal | drowsy | alert',
  confidence       DECIMAL(5,4)    NOT NULL COMMENT 'Model confidence 0.0000–1.0000',
  raw_payload      JSON                NULL DEFAULT NULL COMMENT 'Full model output blob',
  frame_timestamp  DATETIME(3)         NULL DEFAULT NULL COMMENT 'Source frame capture time (ms precision)',
  created_at       DATETIME(3)     NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  PRIMARY KEY (id),
  KEY idx_predictions_session_id  (session_id),
  KEY idx_predictions_worker_id   (worker_id),
  KEY idx_predictions_label       (label),
  KEY idx_predictions_created_at  (created_at),
  CONSTRAINT fk_predictions_session
    FOREIGN KEY (session_id) REFERENCES sessions (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_predictions_worker
    FOREIGN KEY (worker_id) REFERENCES workers (id)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Individual AI inference results from edge devices';


-- =============================================================================
-- TABLE: alerts
-- Raised when a prediction exceeds a configured fatigue threshold.
-- =============================================================================
CREATE TABLE alerts (
  id                  INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  worker_id           INT UNSIGNED    NOT NULL,
  session_id          INT UNSIGNED    NOT NULL,
  prediction_id       INT UNSIGNED    NOT NULL COMMENT 'Triggering prediction',
  severity            ENUM(
                        'low',
                        'medium',
                        'high',
                        'critical'
                      )               NOT NULL,
  status              ENUM(
                        'open',
                        'acknowledged',
                        'resolved'
                      )               NOT NULL DEFAULT 'open',
  message             VARCHAR(512)        NULL DEFAULT NULL,
  acknowledged_by     VARCHAR(255)        NULL DEFAULT NULL,
  acknowledged_at     DATETIME            NULL DEFAULT NULL,
  resolution_notes    TEXT                NULL DEFAULT NULL,
  resolved_at         DATETIME            NULL DEFAULT NULL,
  created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_alerts_worker_id    (worker_id),
  KEY idx_alerts_session_id   (session_id),
  KEY idx_alerts_status       (status),
  KEY idx_alerts_severity     (severity),
  KEY idx_alerts_created_at   (created_at),
  CONSTRAINT fk_alerts_worker
    FOREIGN KEY (worker_id)     REFERENCES workers     (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_alerts_session
    FOREIGN KEY (session_id)    REFERENCES sessions    (id)
    ON DELETE CASCADE  ON UPDATE CASCADE,
  CONSTRAINT fk_alerts_prediction
    FOREIGN KEY (prediction_id) REFERENCES predictions (id)
    ON DELETE CASCADE  ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='Fatigue alerts raised when prediction thresholds are exceeded';

-- =============================================================================
-- End of schema
-- =============================================================================
