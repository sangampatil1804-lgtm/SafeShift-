/**
 * models/alerts.js
 * CRUD operations for the `alerts` table.
 *
 * An alert is raised when the AI model's prediction crosses a configurable
 * fatigue threshold. Alerts are linked to both a worker and the triggering
 * prediction so they can be reviewed in context.
 */

"use strict";

const { pool } = require("../config/db");

// ---------------------------------------------------------------------------
// Create
// ---------------------------------------------------------------------------

/**
 * Create a new fatigue alert.
 * @param {Object} data
 * @param {number}  data.worker_id      - FK → workers.id
 * @param {number}  data.session_id     - FK → sessions.id
 * @param {number}  data.prediction_id  - FK → predictions.id  (the triggering prediction)
 * @param {string}  data.severity       - 'low' | 'medium' | 'high' | 'critical'
 * @param {string}  [data.message]      - Human-readable alert description
 * @returns {Promise<number>} New alert ID
 */
async function createAlert({
  worker_id,
  session_id,
  prediction_id,
  severity,
  message = null,
}) {
  const sql = `
    INSERT INTO alerts (worker_id, session_id, prediction_id, severity, message, status)
    VALUES (?, ?, ?, ?, ?, 'open')
  `;
  const [result] = await pool.execute(sql, [
    worker_id,
    session_id,
    prediction_id,
    severity,
    message,
  ]);
  return result.insertId;
}

// ---------------------------------------------------------------------------
// Read
// ---------------------------------------------------------------------------

/**
 * Fetch all open alerts ordered by most recent first.
 * @param {number} [limit=100]
 * @returns {Promise<Object[]>}
 */
async function getOpenAlerts(limit = 100) {
  const [rows] = await pool.execute(
    `SELECT a.*, w.name AS worker_name, w.employee_id
       FROM alerts a
       JOIN workers w ON w.id = a.worker_id
      WHERE a.status = 'open'
      ORDER BY a.created_at DESC
      LIMIT ?`,
    [limit]
  );
  return rows;
}

/**
 * Fetch all alerts for a specific worker.
 * @param {number} workerId
 * @param {number} [limit=50]
 * @returns {Promise<Object[]>}
 */
async function getAlertsByWorker(workerId, limit = 50) {
  const [rows] = await pool.execute(
    `SELECT * FROM alerts
      WHERE worker_id = ?
      ORDER BY created_at DESC
      LIMIT ?`,
    [workerId, limit]
  );
  return rows;
}

/**
 * Fetch all alerts within a session.
 * @param {number} sessionId
 * @returns {Promise<Object[]>}
 */
async function getAlertsBySession(sessionId) {
  const [rows] = await pool.execute(
    "SELECT * FROM alerts WHERE session_id = ? ORDER BY created_at ASC",
    [sessionId]
  );
  return rows;
}

/**
 * Fetch a single alert by primary key.
 * @param {number} id
 * @returns {Promise<Object|null>}
 */
async function getAlertById(id) {
  const [rows] = await pool.execute(
    "SELECT * FROM alerts WHERE id = ? LIMIT 1",
    [id]
  );
  return rows[0] ?? null;
}

// ---------------------------------------------------------------------------
// Update / Resolve
// ---------------------------------------------------------------------------

/**
 * Acknowledge an alert (status → 'acknowledged').
 * @param {number} id
 * @param {string} [acknowledgedBy]  - Name or ID of the operator who acknowledged
 * @returns {Promise<boolean>}
 */
async function acknowledgeAlert(id, acknowledgedBy = null) {
  const [result] = await pool.execute(
    `UPDATE alerts
        SET status = 'acknowledged', acknowledged_by = ?, acknowledged_at = NOW()
      WHERE id = ? AND status = 'open'`,
    [acknowledgedBy, id]
  );
  return result.affectedRows > 0;
}

/**
 * Resolve/close an alert (status → 'resolved').
 * @param {number} id
 * @param {string} [resolution]  - Optional resolution notes
 * @returns {Promise<boolean>}
 */
async function resolveAlert(id, resolution = null) {
  const [result] = await pool.execute(
    `UPDATE alerts
        SET status = 'resolved', resolution_notes = ?, resolved_at = NOW()
      WHERE id = ?`,
    [resolution, id]
  );
  return result.affectedRows > 0;
}

module.exports = {
  createAlert,
  getOpenAlerts,
  getAlertsByWorker,
  getAlertsBySession,
  getAlertById,
  acknowledgeAlert,
  resolveAlert,
};
