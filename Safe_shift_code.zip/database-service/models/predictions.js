/**
 * models/predictions.js
 * CRUD operations for the `predictions` table.
 *
 * Each prediction is a single inference result emitted by the edge AI model.
 * Predictions belong to a session and optionally trigger alerts.
 */

"use strict";

const { pool } = require("../config/db");

// ---------------------------------------------------------------------------
// Create
// ---------------------------------------------------------------------------

/**
 * Persist one prediction record.
 * @param {Object} data
 * @param {number}  data.session_id         - FK → sessions.id
 * @param {number}  data.worker_id          - FK → workers.id  (denormalized for fast queries)
 * @param {string}  data.label              - Model output label, e.g. 'alert', 'drowsy', 'normal'
 * @param {number}  data.confidence         - Float 0.0–1.0
 * @param {string}  [data.raw_payload]      - Optional JSON blob from the edge device
 * @param {string}  [data.frame_timestamp]  - ISO-8601 timestamp of the source frame
 * @returns {Promise<number>} New prediction ID
 */
async function createPrediction({
  session_id,
  worker_id,
  label,
  confidence,
  raw_payload = null,
  frame_timestamp = null,
}) {
  const sql = `
    INSERT INTO predictions
      (session_id, worker_id, label, confidence, raw_payload, frame_timestamp)
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  const [result] = await pool.execute(sql, [
    session_id,
    worker_id,
    label,
    confidence,
    raw_payload ? JSON.stringify(raw_payload) : null,
    frame_timestamp,
  ]);
  return result.insertId;
}

// ---------------------------------------------------------------------------
// Read
// ---------------------------------------------------------------------------

/**
 * Fetch the most recent N predictions for a given session.
 * @param {number} sessionId
 * @param {number} [limit=50]
 * @returns {Promise<Object[]>}
 */
async function getPredictionsBySession(sessionId, limit = 50) {
  const [rows] = await pool.execute(
    `SELECT * FROM predictions
      WHERE session_id = ?
      ORDER BY created_at DESC
      LIMIT ?`,
    [sessionId, limit]
  );
  return rows;
}

/**
 * Fetch recent predictions for a worker across all sessions.
 * @param {number} workerId
 * @param {number} [limit=100]
 * @returns {Promise<Object[]>}
 */
async function getPredictionsByWorker(workerId, limit = 100) {
  const [rows] = await pool.execute(
    `SELECT * FROM predictions
      WHERE worker_id = ?
      ORDER BY created_at DESC
      LIMIT ?`,
    [workerId, limit]
  );
  return rows;
}

/**
 * Count predictions grouped by label for a session — useful for dashboards.
 * @param {number} sessionId
 * @returns {Promise<Object[]>}  e.g. [{ label: 'drowsy', count: 12 }, ...]
 */
async function getLabelSummaryForSession(sessionId) {
  const [rows] = await pool.execute(
    `SELECT label, COUNT(*) AS count
       FROM predictions
      WHERE session_id = ?
      GROUP BY label`,
    [sessionId]
  );
  return rows;
}

/**
 * Fetch a single prediction by primary key.
 * @param {number} id
 * @returns {Promise<Object|null>}
 */
async function getPredictionById(id) {
  const [rows] = await pool.execute(
    "SELECT * FROM predictions WHERE id = ? LIMIT 1",
    [id]
  );
  return rows[0] ?? null;
}

// ---------------------------------------------------------------------------
// Bulk insert (high-frequency edge streams)
// ---------------------------------------------------------------------------

/**
 * Insert multiple predictions in a single query for throughput-sensitive paths.
 * @param {Object[]} predictions - Array of prediction objects (same shape as createPrediction)
 * @returns {Promise<number>} Number of rows inserted
 */
async function bulkCreatePredictions(predictions) {
  if (!predictions.length) return 0;

  const placeholders = predictions.map(() => "(?, ?, ?, ?, ?, ?)").join(", ");
  const values = predictions.flatMap(
    ({ session_id, worker_id, label, confidence, raw_payload, frame_timestamp }) => [
      session_id,
      worker_id,
      label,
      confidence,
      raw_payload ? JSON.stringify(raw_payload) : null,
      frame_timestamp ?? null,
    ]
  );

  const sql = `
    INSERT INTO predictions
      (session_id, worker_id, label, confidence, raw_payload, frame_timestamp)
    VALUES ${placeholders}
  `;
  const [result] = await pool.execute(sql, values);
  return result.affectedRows;
}

module.exports = {
  createPrediction,
  getPredictionsBySession,
  getPredictionsByWorker,
  getLabelSummaryForSession,
  getPredictionById,
  bulkCreatePredictions,
};
