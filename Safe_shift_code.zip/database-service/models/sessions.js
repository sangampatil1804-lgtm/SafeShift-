/**
 * models/sessions.js
 * CRUD operations for the `sessions` table.
 *
 * A session represents a continuous monitoring window for a single worker
 * (e.g. one shift or one active camera stream). Predictions are tied to sessions.
 */

"use strict";

const { pool } = require("../config/db");

// ---------------------------------------------------------------------------
// Create
// ---------------------------------------------------------------------------

/**
 * Open a new session for a worker.
 * @param {Object} data
 * @param {number} data.worker_id    - FK → workers.id
 * @param {string} [data.device_id]  - Edge device or camera identifier
 * @param {string} [data.location]   - Physical location label
 * @returns {Promise<number>} New session ID
 */
async function createSession({ worker_id, device_id = null, location = null }) {
  const sql = `
    INSERT INTO sessions (worker_id, device_id, location, status, started_at)
    VALUES (?, ?, ?, 'active', NOW())
  `;
  const [result] = await pool.execute(sql, [worker_id, device_id, location]);
  return result.insertId;
}

// ---------------------------------------------------------------------------
// Read
// ---------------------------------------------------------------------------

/**
 * Fetch all sessions, newest first.
 * @param {number} [limit=100]
 * @returns {Promise<Object[]>}
 */
async function getAllSessions(limit = 100) {
  const [rows] = await pool.execute(
    "SELECT * FROM sessions ORDER BY started_at DESC LIMIT ?",
    [limit]
  );
  return rows;
}

/**
 * Fetch a single session by ID.
 * @param {number} id
 * @returns {Promise<Object|null>}
 */
async function getSessionById(id) {
  const [rows] = await pool.execute(
    "SELECT * FROM sessions WHERE id = ? LIMIT 1",
    [id]
  );
  return rows[0] ?? null;
}

/**
 * Fetch all sessions for a specific worker.
 * @param {number} workerId
 * @returns {Promise<Object[]>}
 */
async function getSessionsByWorkerId(workerId) {
  const [rows] = await pool.execute(
    "SELECT * FROM sessions WHERE worker_id = ? ORDER BY started_at DESC",
    [workerId]
  );
  return rows;
}

/**
 * Fetch the currently active session for a worker (status = 'active').
 * @param {number} workerId
 * @returns {Promise<Object|null>}
 */
async function getActiveSessionForWorker(workerId) {
  const [rows] = await pool.execute(
    "SELECT * FROM sessions WHERE worker_id = ? AND status = 'active' LIMIT 1",
    [workerId]
  );
  return rows[0] ?? null;
}

// ---------------------------------------------------------------------------
// Update / Close
// ---------------------------------------------------------------------------

/**
 * Close a session by marking it 'closed' and recording the end timestamp.
 * @param {number} id
 * @returns {Promise<boolean>}
 */
async function closeSession(id) {
  const [result] = await pool.execute(
    `UPDATE sessions
        SET status = 'closed', ended_at = NOW()
      WHERE id = ? AND status = 'active'`,
    [id]
  );
  return result.affectedRows > 0;
}

/**
 * Mark a session as 'error' (e.g. device disconnected unexpectedly).
 * @param {number} id
 * @param {string} [reason]
 * @returns {Promise<boolean>}
 */
async function flagSessionError(id, reason = null) {
  const [result] = await pool.execute(
    `UPDATE sessions
        SET status = 'error', notes = ?, ended_at = NOW()
      WHERE id = ?`,
    [reason, id]
  );
  return result.affectedRows > 0;
}

module.exports = {
  createSession,
  getAllSessions,
  getSessionById,
  getSessionsByWorkerId,
  getActiveSessionForWorker,
  closeSession,
  flagSessionError,
};
