/**
 * models/workers.js
 * CRUD operations for the `workers` table.
 *
 * A worker represents a person being monitored by the fatigue-detection system.
 * Each worker can have many sessions, alerts, and predictions.
 */

"use strict";

const { pool } = require("../config/db");

// ---------------------------------------------------------------------------
// Create
// ---------------------------------------------------------------------------

/**
 * Insert a new worker record.
 * @param {Object} data
 * @param {string} data.employee_id   - Unique employee identifier (e.g. badge number)
 * @param {string} data.name          - Full name
 * @param {string} [data.department]  - Optional department label
 * @param {string} [data.role]        - Optional job role
 * @returns {Promise<number>} Newly created worker's auto-increment ID
 */
async function createWorker({ employee_id, name, department = null, role = null }) {
  const sql = `
    INSERT INTO workers (employee_id, name, department, role)
    VALUES (?, ?, ?, ?)
  `;
  const [result] = await pool.execute(sql, [employee_id, name, department, role]);
  return result.insertId;
}

// ---------------------------------------------------------------------------
// Read
// ---------------------------------------------------------------------------

/**
 * Fetch all active workers (is_active = 1).
 * @returns {Promise<Object[]>}
 */
async function getAllWorkers() {
  const [rows] = await pool.execute(
    "SELECT * FROM workers WHERE is_active = 1 ORDER BY name ASC"
  );
  return rows;
}

/**
 * Fetch a single worker by primary key.
 * @param {number} id
 * @returns {Promise<Object|null>}
 */
async function getWorkerById(id) {
  const [rows] = await pool.execute(
    "SELECT * FROM workers WHERE id = ? LIMIT 1",
    [id]
  );
  return rows[0] ?? null;
}

/**
 * Fetch a worker by their employee_id badge string.
 * @param {string} employeeId
 * @returns {Promise<Object|null>}
 */
async function getWorkerByEmployeeId(employeeId) {
  const [rows] = await pool.execute(
    "SELECT * FROM workers WHERE employee_id = ? LIMIT 1",
    [employeeId]
  );
  return rows[0] ?? null;
}

// ---------------------------------------------------------------------------
// Update
// ---------------------------------------------------------------------------

/**
 * Update mutable fields of a worker record.
 * @param {number} id
 * @param {Object} fields - Any subset of { name, department, role, is_active }
 * @returns {Promise<boolean>} true if a row was updated
 */
async function updateWorker(id, fields) {
  const allowed  = ["name", "department", "role", "is_active"];
  const columns  = Object.keys(fields).filter((k) => allowed.includes(k));
  if (columns.length === 0) return false;

  const setClause = columns.map((c) => `${c} = ?`).join(", ");
  const values    = columns.map((c) => fields[c]);
  values.push(id);

  const [result] = await pool.execute(
    `UPDATE workers SET ${setClause}, updated_at = NOW() WHERE id = ?`,
    values
  );
  return result.affectedRows > 0;
}

// ---------------------------------------------------------------------------
// Soft-delete
// ---------------------------------------------------------------------------

/**
 * Soft-delete a worker by setting is_active = 0.
 * @param {number} id
 * @returns {Promise<boolean>}
 */
async function deactivateWorker(id) {
  const [result] = await pool.execute(
    "UPDATE workers SET is_active = 0, updated_at = NOW() WHERE id = ?",
    [id]
  );
  return result.affectedRows > 0;
}

module.exports = {
  createWorker,
  getAllWorkers,
  getWorkerById,
  getWorkerByEmployeeId,
  updateWorker,
  deactivateWorker,
};
