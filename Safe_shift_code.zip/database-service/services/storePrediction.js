/**
 * services/storePrediction.js
 * Orchestration service for persisting an edge AI prediction.
 *
 * This is the primary write path called by the REST API when an edge device
 * posts inference results. It:
 *   1. Validates and inserts the prediction.
 *   2. Evaluates whether the prediction should trigger a fatigue alert.
 *   3. Creates the alert record if thresholds are exceeded.
 *   4. Returns a structured result the API layer can forward to the client.
 *
 * Keeping this logic in a service (rather than a controller) ensures the
 * business rules are reusable and independently testable.
 */

"use strict";

const { createPrediction }             = require("../models/predictions");
const { createAlert }                  = require("../models/alerts");
const { getActiveSessionForWorker }    = require("../models/sessions");

// ---------------------------------------------------------------------------
// Alert threshold configuration
// Centralised here; move to a DB-backed config table if runtime tuning is needed.
// ---------------------------------------------------------------------------
const ALERT_THRESHOLDS = {
  critical: { labels: ["alert"],   minConfidence: 0.85, severity: "critical" },
  high:     { labels: ["drowsy"],  minConfidence: 0.75, severity: "high"     },
  medium:   { labels: ["drowsy"],  minConfidence: 0.50, severity: "medium"   },
};

/**
 * Evaluate whether a prediction should trigger an alert and return the
 * matching threshold config, or null if no alert should be raised.
 *
 * @param {string} label
 * @param {number} confidence
 * @returns {{ severity: string } | null}
 */
function evaluateThreshold(label, confidence) {
  // Check thresholds from highest to lowest severity
  for (const tier of Object.values(ALERT_THRESHOLDS)) {
    if (tier.labels.includes(label) && confidence >= tier.minConfidence) {
      return { severity: tier.severity };
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Main service function
// ---------------------------------------------------------------------------

/**
 * Persist a prediction from an edge device and trigger alerts as needed.
 *
 * @param {Object}  payload
 * @param {number}  payload.worker_id        - FK → workers.id
 * @param {string}  payload.label            - Model prediction label
 * @param {number}  payload.confidence       - Model confidence score (0–1)
 * @param {string}  [payload.device_id]      - Optional originating device ID
 * @param {Object}  [payload.raw_payload]    - Optional raw model output for audit
 * @param {string}  [payload.frame_timestamp]- ISO-8601 source frame time
 *
 * @returns {Promise<{
 *   predictionId: number,
 *   sessionId:    number,
 *   alertId:      number|null,
 *   alertSeverity:string|null,
 *   label:        string,
 *   confidence:   number,
 * }>}
 *
 * @throws {Error} if no active session exists for the worker
 */
async function storePrediction(payload) {
  const {
    worker_id,
    label,
    confidence,
    raw_payload     = null,
    frame_timestamp = null,
  } = payload;

  // -------------------------------------------------------------------------
  // 1. Resolve the active session for this worker
  // -------------------------------------------------------------------------
  const session = await getActiveSessionForWorker(worker_id);
  if (!session) {
    throw Object.assign(
      new Error(`No active session found for worker ${worker_id}`),
      { code: "NO_ACTIVE_SESSION", statusCode: 409 }
    );
  }

  // -------------------------------------------------------------------------
  // 2. Persist the prediction
  // -------------------------------------------------------------------------
  const predictionId = await createPrediction({
    session_id:      session.id,
    worker_id,
    label,
    confidence,
    raw_payload,
    frame_timestamp,
  });

  // -------------------------------------------------------------------------
  // 3. Check alert thresholds and create alert if needed
  // -------------------------------------------------------------------------
  let alertId       = null;
  let alertSeverity = null;

  const threshold = evaluateThreshold(label, confidence);
  if (threshold) {
    alertSeverity = threshold.severity;
    alertId = await createAlert({
      worker_id,
      session_id:    session.id,
      prediction_id: predictionId,
      severity:      alertSeverity,
      message: `Fatigue detected — label: "${label}", confidence: ${(confidence * 100).toFixed(1)}%`,
    });
  }

  // -------------------------------------------------------------------------
  // 4. Return structured result
  // -------------------------------------------------------------------------
  return {
    predictionId,
    sessionId:    session.id,
    alertId,
    alertSeverity,
    label,
    confidence,
  };
}

module.exports = { storePrediction, evaluateThreshold };
