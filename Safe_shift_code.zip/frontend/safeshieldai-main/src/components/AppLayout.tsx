import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard, History, FileText, Wifi, Settings, LogOut, Users, BarChart3, Shield, Menu, X
} from "lucide-react";
import { useState } from "react";

const employeeNav = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/history", icon: History, label: "History & Analytics" },
  { to: "/reports", icon: FileText, label: "Reports" },
  { to: "/devices", icon: Wifi, label: "Device Status" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

const managerNav = [
  { to: "/", icon: LayoutDashboard, label: "Team Overview" },
  { to: "/history", icon: BarChart3, label: "Team Analytics" },
  { to: "/team", icon: Users, label: "Employees" },
  { to: "/reports", icon: FileText, label: "Reports" },
  { to: "/devices", icon: Wifi, label: "Devices" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const nav = user?.role === "manager" ? managerNav : employeeNav;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-60 transform bg-sidebar transition-transform duration-200 lg:relative lg:translate-x-0 ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex h-full flex-col">
          <div className="flex items-center gap-2.5 px-5 py-5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sidebar-accent">
              <Shield className="h-4 w-4 text-sidebar-foreground" />
            </div>
            <span className="text-base font-bold text-sidebar-primary">SafeShift</span>
            <button onClick={() => setMobileOpen(false)} className="ml-auto text-sidebar-foreground lg:hidden">
              <X className="h-5 w-5" />
            </button>
          </div>

          <nav className="flex-1 space-y-1 px-3 py-2">
            {nav.map(item => {
              const active = location.pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"}`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="border-t border-sidebar-border p-3">
            <div className="mb-2 px-3 py-1">
              <p className="text-sm font-medium text-sidebar-foreground">{user?.name}</p>
              <p className="text-xs text-sidebar-foreground/50">{user?.role}</p>
            </div>
            <button onClick={handleLogout} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/70 transition-all hover:bg-sidebar-accent/50 hover:text-sidebar-foreground">
              <LogOut className="h-4 w-4" />
              Sign out
            </button>
          </div>
        </div>
      </aside>

      {/* Overlay */}
      {mobileOpen && <div className="fixed inset-0 z-40 bg-foreground/20 lg:hidden" onClick={() => setMobileOpen(false)} />}

      {/* Main */}
      <main className="flex-1 overflow-auto">
        <header className="sticky top-0 z-30 border-b border-border bg-background/95 px-4 py-3 backdrop-blur lg:px-6">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileOpen(true)} className="lg:hidden text-foreground">
              <Menu className="h-5 w-5" />
            </button>
            <h2 className="text-lg font-semibold text-foreground">{nav.find(n => n.to === location.pathname)?.label || "Dashboard"}</h2>
          </div>
          <p className="mt-1 text-xs text-muted-foreground lg:text-sm">
            SafeShift: Affordable AI-Powered Protection System for Real-Time Micro-Sleep Detection and Alert to Enhance Safety
          </p>
        </header>
        <div className="p-4 lg:p-6">{children}</div>
      </main>
    </div>
  );
}
