import type { ReactNode } from "react";

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: ReactNode;
  variant?: "default" | "warning" | "critical";
}

export default function MetricCard({ title, value, subtitle, icon, variant = "default" }: MetricCardProps) {
  const border = variant === "critical" ? "border-foreground/30" : variant === "warning" ? "border-foreground/15" : "border-border";
  return (
    <div className={`rounded-xl border ${border} bg-card p-5 transition-all hover:shadow-md`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="mt-1 text-2xl font-bold text-card-foreground">{value}</p>
          {subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>}
        </div>
        <div className="rounded-lg bg-muted p-2.5 text-muted-foreground">{icon}</div>
      </div>
    </div>
  );
}
