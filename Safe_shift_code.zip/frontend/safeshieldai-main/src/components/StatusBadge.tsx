import type { FatigueStatus } from "@/types";

interface StatusBadgeProps {
  status: FatigueStatus;
  size?: "sm" | "md";
}

export default function StatusBadge({ status, size = "sm" }: StatusBadgeProps) {
  const classes = {
    Normal: "status-safe",
    Fatigue: "status-warning",
    Drowsy: "status-warning",
    Microsleep: "status-critical",
  };
  const s = size === "sm" ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-sm";
  return (
    <span className={`inline-flex items-center rounded-full font-medium ${classes[status]} ${s}`}>
      {status === "Microsleep" && <span className="mr-1 h-1.5 w-1.5 animate-pulse-alert rounded-full bg-current" />}
      {status}
    </span>
  );
}
