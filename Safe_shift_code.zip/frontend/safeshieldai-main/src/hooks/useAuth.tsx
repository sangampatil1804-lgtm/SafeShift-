import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import type { User } from "@/types";
import { authApi } from "@/services/api";

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, role: "employee" | "manager") => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem("safeshift_user");
    return stored ? JSON.parse(stored) : null;
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("safeshift_token"));

  const login = useCallback(async (email: string, password: string) => {
    const res = await authApi.login(email, password);
    setUser(res.user);
    setToken(res.token);
    localStorage.setItem("safeshift_user", JSON.stringify(res.user));
    localStorage.setItem("safeshift_token", res.token);
  }, []);

  const register = useCallback(async (name: string, email: string, password: string, role: "employee" | "manager") => {
    const res = await authApi.register(name, email, password, role);
    setUser(res.user);
    setToken(res.token);
    localStorage.setItem("safeshift_user", JSON.stringify(res.user));
    localStorage.setItem("safeshift_token", res.token);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("safeshift_user");
    localStorage.removeItem("safeshift_token");
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
