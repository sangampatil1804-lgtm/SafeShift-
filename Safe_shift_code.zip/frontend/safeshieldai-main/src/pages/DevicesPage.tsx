import { Camera, Wifi, WifiOff, Heart, Clock } from "lucide-react";

const devices = [
  { name: "Eye Tracking Camera", type: "camera", status: "connected" as const, lastSync: "2 seconds ago" },
  { name: "Heart Rate Sensor", type: "sensor", status: "connected" as const, lastSync: "5 seconds ago" },
  { name: "Backup Camera", type: "camera", status: "disconnected" as const, lastSync: "3 hours ago" },
];

export default function DevicesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground">Device Status</h3>
        <p className="text-sm text-muted-foreground">Monitor connected sensors and cameras</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {devices.map(d => (
          <div key={d.name} className={`rounded-xl border bg-card p-5 transition-all hover:shadow-md ${d.status === "connected" ? "border-border" : "border-foreground/20"}`}>
            <div className="flex items-start justify-between">
              <div className="rounded-lg bg-muted p-2.5">
                {d.type === "camera" ? <Camera className="h-5 w-5 text-muted-foreground" /> : <Heart className="h-5 w-5 text-muted-foreground" />}
              </div>
              <div className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${d.status === "connected" ? "status-safe" : "status-critical"}`}>
                {d.status === "connected" ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
                {d.status === "connected" ? "Connected" : "Disconnected"}
              </div>
            </div>
            <h4 className="mt-4 font-medium text-card-foreground">{d.name}</h4>
            <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              Last sync: {d.lastSync}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
