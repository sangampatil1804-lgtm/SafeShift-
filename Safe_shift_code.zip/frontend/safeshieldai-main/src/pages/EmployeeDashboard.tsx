import { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { dataApi } from "@/services/api";
import type { HealthData, Alert } from "@/types";
import MetricCard from "@/components/MetricCard";
import StatusBadge from "@/components/StatusBadge";
import { Heart, Eye, Activity, AlertTriangle, Camera, Clock } from "lucide-react";
import { toast } from "sonner";

export default function EmployeeDashboard() {
  const { user } = useAuth();
  const [health, setHealth] = useState<HealthData | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);

  const fetchData = useCallback(async () => {
    if (!user) return;
    const [h, a] = await Promise.all([dataApi.getRealtime(user.id), dataApi.getAlerts(user.id)]);
    if (h.fatigueStatus !== "Normal" && health?.fatigueStatus === "Normal") {
      toast.error(h.fatigueStatus === "Microsleep" ? "⚠️ Microsleep Alert" : h.fatigueStatus === "Drowsy" ? "⚠️ Drowsiness Warning" : "Fatigue Detected");
    }
    setHealth(h);
    setAlerts(a);
  }, [user, health?.fatigueStatus]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, [fetchData]);

  if (!health) return <div className="flex items-center justify-center py-20 text-muted-foreground">Loading...</div>;

  const variant = health.fatigueStatus === "Microsleep" ? "critical" : health.fatigueStatus !== "Normal" ? "warning" : "default";

  return (
    <div className="space-y-6">
      {/* Status Banner */}
      {health.fatigueStatus !== "Normal" && (
        <div className={`rounded-xl p-4 ${health.fatigueStatus === "Microsleep" ? "status-critical" : "status-warning"}`}>
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-5 w-5" />
            <div>
              <p className="font-semibold">{health.fatigueStatus === "Microsleep" ? "Microsleep Alert" : health.fatigueStatus === "Drowsy" ? "Drowsiness Warning" : "Fatigue Detected"}</p>
              <p className="text-sm opacity-80">Please take a break immediately</p>
            </div>
          </div>
        </div>
      )}

      {/* Metrics */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard title="Heart Rate" value={`${health.heartRate} BPM`} icon={<Heart className="h-5 w-5" />} variant={variant} subtitle={health.heartRate > 90 ? "Elevated" : "Normal range"} />
        <MetricCard title="Eye Aspect Ratio" value={health.earValue.toFixed(3)} icon={<Eye className="h-5 w-5" />} variant={variant} subtitle={`Eyes ${health.eyeStatus}`} />
        <MetricCard title="Fatigue Score" value={health.fatigueScore.toFixed(1)} icon={<Activity className="h-5 w-5" />} variant={variant} subtitle={health.fatigueStatus} />
        <MetricCard title="Alert Status" value={health.fatigueStatus} icon={<AlertTriangle className="h-5 w-5" />} variant={variant} />
      </div>

      {/* Live Feed + Status */}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5">
          <h3 className="mb-4 font-semibold text-card-foreground">Real-Time Monitoring</h3>
          <div className="flex aspect-video items-center justify-center rounded-lg bg-muted">
            <div className="text-center text-muted-foreground">
              <Camera className="mx-auto mb-2 h-10 w-10" />
              <p className="text-sm font-medium">Live Camera Feed</p>
              <p className="text-xs">Placeholder for CV integration</p>
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <StatusBadge status={health.fatigueStatus} size="md" />
              <span>Eye: {health.eyeStatus}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              {new Date(health.timestamp).toLocaleTimeString()}
            </div>
          </div>
        </div>

        {/* Recent Alerts */}
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-4 font-semibold text-card-foreground">Recent Alerts</h3>
          <div className="space-y-3 max-h-80 overflow-auto">
            {alerts.slice(0, 8).map(alert => (
              <div key={alert.id} className={`rounded-lg p-3 text-sm ${alert.type === "microsleep" ? "status-critical" : alert.type === "drowsiness" ? "status-warning" : "bg-muted text-muted-foreground"}`}>
                <p className="font-medium">{alert.message}</p>
                <p className="mt-0.5 text-xs opacity-70">{new Date(alert.timestamp).toLocaleString()}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
