import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { dataApi, adminApi } from "@/services/api";
import type { HealthData } from "@/types";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

export default function HistoryPage() {
  const { user } = useAuth();
  const [healthData, setHealthData] = useState<HealthData[]>([]);
  const [analytics, setAnalytics] = useState<any[]>([]);
  const [filter, setFilter] = useState<"daily" | "weekly">("daily");

  useEffect(() => {
    if (!user) return;
    const days = filter === "daily" ? 1 : 7;
    dataApi.getHistory(user.id, days).then(setHealthData);
    if (user.role === "manager") {
      adminApi.getAnalytics().then(setAnalytics);
    }
  }, [user, filter]);

  const chartData = healthData.map(h => ({
    time: new Date(h.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    heartRate: h.heartRate,
    fatigueScore: h.fatigueScore,
    earValue: h.earValue * 100,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        {(["daily", "weekly"] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${filter === f ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"}`}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Fatigue Trend */}
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-4 font-semibold text-card-foreground">Fatigue Score Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 88%)" />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <YAxis tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid hsl(0 0% 88%)", fontSize: 12 }} />
              <Line type="monotone" dataKey="fatigueScore" stroke="hsl(0 0% 20%)" strokeWidth={2} dot={false} name="Fatigue Score" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Heart Rate */}
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-4 font-semibold text-card-foreground">Heart Rate</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 88%)" />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <YAxis tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid hsl(0 0% 88%)", fontSize: 12 }} />
              <Line type="monotone" dataKey="heartRate" stroke="hsl(0 0% 40%)" strokeWidth={2} dot={false} name="BPM" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Alert frequency (manager or employee) */}
      {user?.role === "manager" && analytics.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-4 font-semibold text-card-foreground">Alert Frequency (Team)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={analytics}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 88%)" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <YAxis tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid hsl(0 0% 88%)", fontSize: 12 }} />
              <Legend />
              <Bar dataKey="fatigueCount" fill="hsl(0 0% 70%)" name="Fatigue" radius={[4, 4, 0, 0]} />
              <Bar dataKey="drowsyCount" fill="hsl(0 0% 45%)" name="Drowsy" radius={[4, 4, 0, 0]} />
              <Bar dataKey="microsleepCount" fill="hsl(0 0% 15%)" name="Microsleep" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Alert History Table */}
      <div className="rounded-xl border border-border bg-card">
        <div className="border-b border-border p-5">
          <h3 className="font-semibold text-card-foreground">EAR Trend</h3>
        </div>
        <div className="p-5">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 88%)" />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <YAxis tick={{ fontSize: 11, fill: "hsl(0 0% 45%)" }} />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid hsl(0 0% 88%)", fontSize: 12 }} />
              <Line type="monotone" dataKey="earValue" stroke="hsl(0 0% 55%)" strokeWidth={2} dot={false} name="EAR ×100" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
