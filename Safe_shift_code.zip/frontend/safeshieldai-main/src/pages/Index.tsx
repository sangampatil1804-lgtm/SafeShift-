import { useAuth } from "@/hooks/useAuth";
import EmployeeDashboard from "@/pages/EmployeeDashboard";
import ManagerDashboard from "@/pages/ManagerDashboard";

export default function Index() {
  const { user } = useAuth();
  return user?.role === "manager" ? <ManagerDashboard /> : <EmployeeDashboard />;
}
