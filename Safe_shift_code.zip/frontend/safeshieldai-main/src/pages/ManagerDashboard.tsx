import { useEffect, useState } from "react";
import { adminApi } from "@/services/api";
import type { EmployeeOverview } from "@/types";
import MetricCard from "@/components/MetricCard";
import StatusBadge from "@/components/StatusBadge";
import { Users, AlertTriangle, Activity, Shield } from "lucide-react";

export default function ManagerDashboard() {
  const [employees, setEmployees] = useState<EmployeeOverview[]>([]);

  useEffect(() => {
    adminApi.getUsers().then(setEmployees);
    const interval = setInterval(() => adminApi.getUsers().then(setEmployees), 8000);
    return () => clearInterval(interval);
  }, []);

  const total = employees.length;
  const critical = employees.filter(e => e.latestHealth.fatigueStatus === "Microsleep" || e.latestHealth.fatigueStatus === "Drowsy").length;
  const fatigued = employees.filter(e => e.latestHealth.fatigueStatus === "Fatigue").length;
  const normal = employees.filter(e => e.latestHealth.fatigueStatus === "Normal").length;

  return (
    <div className="space-y-6">
      {critical > 0 && (
        <div className="status-critical rounded-xl p-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-5 w-5" />
            <p className="font-semibold">{critical} employee(s) in critical state — immediate attention required</p>
          </div>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard title="Total Employees" value={total} icon={<Users className="h-5 w-5" />} />
        <MetricCard title="Normal" value={normal} icon={<Shield className="h-5 w-5" />} subtitle="Active & safe" />
        <MetricCard title="Fatigued" value={fatigued} icon={<Activity className="h-5 w-5" />} variant="warning" />
        <MetricCard title="High Risk" value={critical} icon={<AlertTriangle className="h-5 w-5" />} variant={critical > 0 ? "critical" : "default"} />
      </div>

      {/* Employee Table */}
      <div className="rounded-xl border border-border bg-card">
        <div className="p-5 border-b border-border">
          <h3 className="font-semibold text-card-foreground">Employee Status</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="px-5 py-3 text-left font-medium text-muted-foreground">Name</th>
                <th className="px-5 py-3 text-left font-medium text-muted-foreground">Status</th>
                <th className="px-5 py-3 text-left font-medium text-muted-foreground">Heart Rate</th>
                <th className="px-5 py-3 text-left font-medium text-muted-foreground">EAR</th>
                <th className="px-5 py-3 text-left font-medium text-muted-foreground">Fatigue Score</th>
                <th className="px-5 py-3 text-left font-medium text-muted-foreground">Last Alert</th>
              </tr>
            </thead>
            <tbody>
              {employees.map(emp => (
                <tr key={emp.user.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-5 py-3 font-medium text-card-foreground">{emp.user.name}</td>
                  <td className="px-5 py-3"><StatusBadge status={emp.latestHealth.fatigueStatus} /></td>
                  <td className="px-5 py-3 text-muted-foreground">{emp.latestHealth.heartRate} BPM</td>
                  <td className="px-5 py-3 text-muted-foreground">{emp.latestHealth.earValue.toFixed(3)}</td>
                  <td className="px-5 py-3 text-muted-foreground">{emp.latestHealth.fatigueScore.toFixed(1)}</td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">{emp.lastAlert ? new Date(emp.lastAlert.timestamp).toLocaleString() : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
