import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { reportApi } from "@/services/api";
import { FileText, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function ReportsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [reports] = useState([
    { id: "1", date: "2024-03-15", type: "Daily Summary" },
    { id: "2", date: "2024-03-14", type: "Weekly Report" },
    { id: "3", date: "2024-03-10", type: "Daily Summary" },
  ]);

  const handleGenerate = async () => {
    if (!user) return;
    setLoading(true);
    try {
      await reportApi.generate(user.id);
      toast.success("Report generated successfully!");
    } catch {
      toast.error("Failed to generate report");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-foreground">{user?.role === "manager" ? "Team Reports" : "My Reports"}</h3>
          <p className="text-sm text-muted-foreground">Generate and download fatigue analysis reports</p>
        </div>
        <button onClick={handleGenerate} disabled={loading} className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-all hover:opacity-90 disabled:opacity-50">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
          {loading ? "Generating..." : "Generate Report"}
        </button>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <div className="border-b border-border p-5">
          <h4 className="font-medium text-card-foreground">Report History</h4>
        </div>
        <div className="divide-y divide-border">
          {reports.map(r => (
            <div key={r.id} className="flex items-center justify-between px-5 py-4 hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-muted p-2"><FileText className="h-4 w-4 text-muted-foreground" /></div>
                <div>
                  <p className="text-sm font-medium text-card-foreground">{r.type}</p>
                  <p className="text-xs text-muted-foreground">{r.date}</p>
                </div>
              </div>
              <button className="rounded-lg p-2 text-muted-foreground hover:bg-muted transition-colors">
                <Download className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Report Preview Card */}
      <div className="rounded-xl border border-border bg-card p-5">
        <h4 className="mb-3 font-medium text-card-foreground">Report Contents</h4>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li>• User information and shift details</li>
          <li>• Fatigue summary with average scores</li>
          <li>• Complete alert history log</li>
          <li>• Heart rate and EAR trend data</li>
          <li>• Recommendations based on fatigue patterns</li>
        </ul>
      </div>
    </div>
  );
}
