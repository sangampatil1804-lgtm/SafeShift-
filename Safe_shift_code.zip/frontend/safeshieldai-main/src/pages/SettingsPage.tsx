import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { User, Bell, LogOut } from "lucide-react";
import { toast } from "sonner";

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="max-w-2xl space-y-6">
      {/* Profile */}
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-3 mb-5">
          <User className="h-5 w-5 text-muted-foreground" />
          <h3 className="font-semibold text-card-foreground">Profile</h3>
        </div>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-foreground">Name</label>
            <input type="text" defaultValue={user?.name} className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-foreground">Email</label>
            <input type="email" defaultValue={user?.email} className="w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-muted-foreground">Role</label>
            <p className="text-sm font-medium text-foreground capitalize">{user?.role}</p>
          </div>
          <button onClick={() => toast.success("Profile updated!")} className="rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-all hover:opacity-90">
            Save Changes
          </button>
        </div>
      </div>

      {/* Alert Preferences */}
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-3 mb-5">
          <Bell className="h-5 w-5 text-muted-foreground" />
          <h3 className="font-semibold text-card-foreground">Alert Preferences</h3>
        </div>
        <div className="space-y-3">
          {["Fatigue alerts", "Drowsiness warnings", "Microsleep alerts", "Email notifications"].map(pref => (
            <label key={pref} className="flex items-center justify-between">
              <span className="text-sm text-foreground">{pref}</span>
              <input type="checkbox" defaultChecked className="h-4 w-4 rounded border-input accent-foreground" />
            </label>
          ))}
        </div>
      </div>

      {/* Logout */}
      <button onClick={handleLogout} className="flex items-center gap-2 rounded-lg border border-border px-4 py-2.5 text-sm font-medium text-foreground transition-all hover:bg-muted">
        <LogOut className="h-4 w-4" />
        Sign Out
      </button>
    </div>
  );
}
