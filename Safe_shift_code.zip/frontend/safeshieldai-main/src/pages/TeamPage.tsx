import { useEffect, useState } from "react";
import { adminApi } from "@/services/api";
import type { EmployeeOverview } from "@/types";
import StatusBadge from "@/components/StatusBadge";

export default function TeamPage() {
  const [employees, setEmployees] = useState<EmployeeOverview[]>([]);

  useEffect(() => {
    adminApi.getUsers().then(setEmployees);
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-foreground">All Employees</h3>
        <p className="text-sm text-muted-foreground">Manage and monitor team members</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {employees.map(emp => (
          <div key={emp.user.id} className="rounded-xl border border-border bg-card p-5 transition-all hover:shadow-md">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="font-medium text-card-foreground">{emp.user.name}</h4>
                <p className="text-xs text-muted-foreground">{emp.user.email}</p>
              </div>
              <StatusBadge status={emp.latestHealth.fatigueStatus} />
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-lg bg-muted p-2">
                <p className="text-xs text-muted-foreground">HR</p>
                <p className="text-sm font-semibold text-card-foreground">{emp.latestHealth.heartRate}</p>
              </div>
              <div className="rounded-lg bg-muted p-2">
                <p className="text-xs text-muted-foreground">EAR</p>
                <p className="text-sm font-semibold text-card-foreground">{emp.latestHealth.earValue.toFixed(2)}</p>
              </div>
              <div className="rounded-lg bg-muted p-2">
                <p className="text-xs text-muted-foreground">Score</p>
                <p className="text-sm font-semibold text-card-foreground">{emp.latestHealth.fatigueScore.toFixed(0)}</p>
              </div>
            </div>
            {emp.lastAlert && (
              <p className="mt-3 text-xs text-muted-foreground">Last alert: {new Date(emp.lastAlert.timestamp).toLocaleString()}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
