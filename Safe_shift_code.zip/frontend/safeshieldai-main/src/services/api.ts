// Mock API service - designed for easy replacement with real Axios calls
import type { User, HealthData, Alert, AuthResponse, EmployeeOverview, FatigueStatus } from "@/types";

const delay = (ms: number) => new Promise(r => setTimeout(r, ms));

const MOCK_USERS: User[] = [
  { id: "1", name: "John Doe", email: "john@safeshiftinc.com", role: "employee" },
  { id: "2", name: "Jane Smith", email: "jane@safeshiftinc.com", role: "employee" },
  { id: "3", name: "Alex Chen", email: "alex@safeshiftinc.com", role: "employee" },
  { id: "4", name: "Sara Wilson", email: "sara@safeshiftinc.com", role: "employee" },
  { id: "5", name: "Mike Johnson", email: "mike@safeshiftinc.com", role: "manager" },
];

const statuses: FatigueStatus[] = ["Normal", "Normal", "Normal", "Fatigue", "Drowsy", "Microsleep"];

function randomHealth(userId: string, ts?: string): HealthData {
  const status = statuses[Math.floor(Math.random() * statuses.length)];
  return {
    id: Math.random().toString(36).slice(2),
    userId,
    heartRate: 60 + Math.floor(Math.random() * 40),
    earValue: parseFloat((0.15 + Math.random() * 0.2).toFixed(3)),
    fatigueScore: status === "Normal" ? Math.random() * 30 : status === "Fatigue" ? 30 + Math.random() * 30 : 60 + Math.random() * 40,
    fatigueStatus: status,
    eyeStatus: status === "Microsleep" ? "Closed" : Math.random() > 0.2 ? "Open" : "Closed",
    timestamp: ts || new Date().toISOString(),
  };
}

function randomAlert(userId: string, ts?: string): Alert {
  const types = ["fatigue", "drowsiness", "microsleep"] as const;
  const messages = { fatigue: "Fatigue Detected", drowsiness: "Drowsiness Warning", microsleep: "Microsleep Alert" };
  const type = types[Math.floor(Math.random() * types.length)];
  return {
    id: Math.random().toString(36).slice(2),
    userId,
    type,
    message: messages[type],
    timestamp: ts || new Date().toISOString(),
    read: Math.random() > 0.5,
  };
}

// Auth APIs
export const authApi = {
  login: async (email: string, _password: string): Promise<AuthResponse> => {
    await delay(600);
    const user = MOCK_USERS.find(u => u.email === email);
    if (!user) throw new Error("Invalid credentials");
    return { user, token: "mock-jwt-token-" + user.id };
  },
  register: async (name: string, email: string, _password: string, role: "employee" | "manager"): Promise<AuthResponse> => {
    await delay(600);
    const user: User = { id: Math.random().toString(36).slice(2), name, email, role };
    return { user, token: "mock-jwt-token-" + user.id };
  },
  forgotPassword: async (_email: string): Promise<{ message: string }> => {
    await delay(400);
    return { message: "Password reset link sent to your email." };
  },
};

// Employee data APIs
export const dataApi = {
  getRealtime: async (userId: string): Promise<HealthData> => {
    await delay(300);
    return randomHealth(userId);
  },
  getHistory: async (userId: string, days: number = 7): Promise<HealthData[]> => {
    await delay(400);
    const data: HealthData[] = [];
    const now = Date.now();
    for (let i = 0; i < days * 8; i++) {
      const ts = new Date(now - i * 3 * 3600000).toISOString();
      data.push(randomHealth(userId, ts));
    }
    return data.reverse();
  },
  getAlerts: async (userId: string): Promise<Alert[]> => {
    await delay(300);
    const alerts: Alert[] = [];
    const now = Date.now();
    for (let i = 0; i < 15; i++) {
      alerts.push(randomAlert(userId, new Date(now - i * 7200000).toISOString()));
    }
    return alerts;
  },
};

// Manager APIs
export const adminApi = {
  getUsers: async (): Promise<EmployeeOverview[]> => {
    await delay(500);
    return MOCK_USERS.filter(u => u.role === "employee").map(user => ({
      user,
      latestHealth: randomHealth(user.id),
      lastAlert: Math.random() > 0.4 ? randomAlert(user.id) : undefined,
    }));
  },
  getAnalytics: async (): Promise<{ date: string; fatigueCount: number; drowsyCount: number; microsleepCount: number; normalCount: number }[]> => {
    await delay(400);
    const data = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      data.push({
        date: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        normalCount: 15 + Math.floor(Math.random() * 10),
        fatigueCount: Math.floor(Math.random() * 8),
        drowsyCount: Math.floor(Math.random() * 5),
        microsleepCount: Math.floor(Math.random() * 3),
      });
    }
    return data;
  },
};

// ML placeholder APIs
export const mlApi = {
  postEyeData: async (_data: { earValue: number; blinkRate: number }) => {
    await delay(200);
    return { status: "received", prediction: "Normal" };
  },
  postHeartRate: async (_data: { heartRate: number; hrv: number }) => {
    await delay(200);
    return { status: "received" };
  },
  predictFatigue: async (_data: { earValue: number; heartRate: number; hrv: number }) => {
    await delay(300);
    const statuses: FatigueStatus[] = ["Normal", "Fatigue", "Drowsy"];
    return { fatigueStatus: statuses[Math.floor(Math.random() * statuses.length)], confidence: 0.85 + Math.random() * 0.15 };
  },
};

// Reports
export const reportApi = {
  generate: async (_userId: string): Promise<{ reportUrl: string }> => {
    await delay(800);
    return { reportUrl: "/mock-report.pdf" };
  },
};
