// Types for SafeShift system

export type UserRole = "employee" | "manager";

export type FatigueStatus = "Normal" | "Fatigue" | "Drowsy" | "Microsleep";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export interface HealthData {
  id: string;
  userId: string;
  heartRate: number;
  earValue: number;
  fatigueScore: number;
  fatigueStatus: FatigueStatus;
  eyeStatus: "Open" | "Closed";
  timestamp: string;
}

export interface Alert {
  id: string;
  userId: string;
  type: "fatigue" | "drowsiness" | "microsleep";
  message: string;
  timestamp: string;
  read: boolean;
}

export interface Report {
  id: string;
  userId: string;
  reportPath: string;
  createdAt: string;
}

export interface EmployeeOverview {
  user: User;
  latestHealth: HealthData;
  lastAlert?: Alert;
}

export interface AuthResponse {
  user: User;
  token: string;
}
